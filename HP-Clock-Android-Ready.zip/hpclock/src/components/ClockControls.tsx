import React from 'react';
import { TimeFormat, ThemeMode } from '../types';

interface ClockControlsProps {
  format: TimeFormat;
  onToggleFormat: () => void;
  theme: ThemeMode;
  onToggleTheme: () => void;
  showSeconds: boolean;
  onToggleSeconds: () => void;
}

export const ClockControls: React.FC<ClockControlsProps> = ({
  format,
  onToggleFormat,
  theme,
  onToggleTheme,
  showSeconds,
  onToggleSeconds,
}) => {
  const isDark = theme === 'dark';

  return (
    <div
      id="clock-controls"
      className="w-full max-w-2xl mx-auto border-t border-b border-[#1A1A1A] dark:border-[#F8F7F4]/20 my-4 sm:my-6 transition-colors"
    >
      <div className="grid grid-cols-3 divide-x divide-[#1A1A1A]/10 dark:divide-[#F8F7F4]/10">
        {/* Format Control */}
        <button
          id="toggle-format-button"
          onClick={onToggleFormat}
          aria-label="Toggle 12-hour or 24-hour time format"
          className="p-3 sm:p-5 flex flex-col items-start gap-1 cursor-pointer transition-colors hover:bg-[#1A1A1A]/5 dark:hover:bg-white/5 active:bg-[#1A1A1A]/10 text-left w-full"
        >
          <span className="label text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60">
            Format System
          </span>
          <strong className="text-xs sm:text-sm font-semibold tracking-tight text-[#1A1A1A] dark:text-[#F8F7F4]">
            {format === '12h' ? '12H Mode' : '24H Mode'}
          </strong>
        </button>

        {/* Theme Control */}
        <button
          id="toggle-theme-button"
          onClick={onToggleTheme}
          aria-label="Toggle light or dark theme appearance"
          className="p-3 sm:p-5 flex flex-col items-start gap-1 cursor-pointer transition-colors hover:bg-[#1A1A1A]/5 dark:hover:bg-white/5 active:bg-[#1A1A1A]/10 text-left w-full"
        >
          <span className="label text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60">
            Appearance
          </span>
          <strong className="text-xs sm:text-sm font-semibold tracking-tight text-[#1A1A1A] dark:text-[#F8F7F4]">
            {isDark ? 'Dark Applied' : 'Light Applied'}
          </strong>
        </button>

        {/* Seconds Control */}
        <button
          id="toggle-seconds-button"
          onClick={onToggleSeconds}
          aria-label="Toggle visibility of seconds"
          className="p-3 sm:p-5 flex flex-col items-start gap-1 cursor-pointer transition-colors hover:bg-[#1A1A1A]/5 dark:hover:bg-white/5 active:bg-[#1A1A1A]/10 text-left w-full"
        >
          <span className="label text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60">
            Visuals
          </span>
          <strong className="text-xs sm:text-sm font-semibold tracking-tight text-[#1A1A1A] dark:text-[#F8F7F4]">
            {showSeconds ? 'Show Seconds' : 'Hide Seconds'}
          </strong>
        </button>
      </div>
    </div>
  );
};

