import React from 'react';
import { ActiveTab, ThemeMode } from '../types';
import { soundManager } from '../utils/audioAlert';

interface BottomNavProps {
  activeTab: ActiveTab;
  onTabChange: (tab: ActiveTab) => void;
  theme: ThemeMode;
  alarmCount: number;
  activeTimerRunning: boolean;
  stopwatchRunning: boolean;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onTabChange,
  theme,
  alarmCount,
  activeTimerRunning,
  stopwatchRunning,
}) => {
  const isDark = theme === 'dark';

  const navItems = [
    {
      id: 'clock' as ActiveTab,
      label: 'Clock',
      badge: null,
    },
    {
      id: 'alarm' as ActiveTab,
      label: 'Alarm',
      badge: alarmCount > 0 ? `[${alarmCount}]` : null,
    },
    {
      id: 'stopwatch' as ActiveTab,
      label: 'Stopwatch',
      badge: stopwatchRunning ? '[•]' : null,
    },
    {
      id: 'timer' as ActiveTab,
      label: 'Timer',
      badge: activeTimerRunning ? '[•]' : null,
    },
    {
      id: 'worldclock' as ActiveTab,
      label: 'World Clock',
      badge: null,
    },
  ];

  return (
    <footer
      id="bottom-navigation-bar"
      className="fixed bottom-0 left-0 right-0 z-40 bg-[#F8F7F4] text-[#1A1A1A] dark:bg-[#121214] dark:text-[#F8F7F4] border-t border-[#1A1A1A] dark:border-[#F8F7F4]/30 px-4 sm:px-8 py-3 transition-colors select-none"
    >
      <div className="max-w-6xl mx-auto flex items-center justify-between gap-4">
        {/* Navigation links matching the design .nav-btn */}
        <div className="flex items-center gap-2 sm:gap-6 overflow-x-auto py-1 scrollbar-none">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`nav-tab-${item.id}`}
                onClick={() => {
                  soundManager.playTap();
                  onTabChange(item.id);
                }}
                className={`font-sans text-xs sm:text-sm font-medium transition-all whitespace-nowrap cursor-pointer px-2 sm:px-4 py-1.5 flex items-center gap-1.5 border-b-2 ${
                  isActive
                    ? 'border-[#B8860B] dark:border-[#D4AF37] text-[#1A1A1A] dark:text-white font-semibold'
                    : 'border-transparent text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60 hover:text-[#1A1A1A] dark:hover:text-white'
                }`}
              >
                <span>{item.label}</span>
                {item.badge && (
                  <span className="text-[#B8860B] dark:text-[#D4AF37] text-[10px] font-mono-display font-bold">
                    {item.badge}
                  </span>
                )}
              </button>
            );
          })}
        </div>

        {/* Footer Label */}
        <span className="label text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60 hidden md:inline-block shrink-0">
          © 2026 HP CLOCK UI
        </span>
      </div>
    </footer>
  );
};

