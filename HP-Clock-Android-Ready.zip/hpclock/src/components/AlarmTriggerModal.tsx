import React, { useEffect, useState } from 'react';
import { Check, AlarmClock, BellRing } from 'lucide-react';
import { AlarmItem, ThemeMode, TimeFormat } from '../types';
import { soundManager } from '../utils/audioAlert';
import { formatAlarmTime } from '../utils/alarmUtils';

interface AlarmTriggerModalProps {
  alarm: AlarmItem;
  theme: ThemeMode;
  format: TimeFormat;
  onDismiss: () => void;
  onSnooze: (minutes: number) => void;
}

export const AlarmTriggerModal: React.FC<AlarmTriggerModalProps> = ({
  alarm,
  theme,
  format,
  onDismiss,
  onSnooze,
}) => {
  const isDark = theme === 'dark';
  const defaultSnooze = alarm.snoozeDuration || 5;
  const [selectedSnooze, setSelectedSnooze] = useState<number>(defaultSnooze);
  const formattedTime = formatAlarmTime(alarm.time, format);

  useEffect(() => {
    soundManager.startAlarmTone();

    return () => {
      soundManager.stopAlarmTone();
    };
  }, []);

  const handleDismiss = () => {
    soundManager.stopAlarmTone();
    onDismiss();
  };

  const handleSnooze = (minutes: number) => {
    soundManager.stopAlarmTone();
    onSnooze(minutes);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in zoom-in-95 duration-200">
      <div
        className={`w-full max-w-md rounded-3xl p-6 sm:p-8 shadow-2xl border-[1.5px] flex flex-col items-center text-center relative overflow-hidden ${
          isDark
            ? 'bg-[#18181B] border-[#F8F7F4]/40 text-[#F8F7F4] shadow-[8px_8px_0_#6366F1]'
            : 'bg-white border-[#1A1A1A] text-[#1A1A1A] shadow-[8px_8px_0_#1A1A1A]'
        }`}
      >
        {/* Pulsing Alarm Icon */}
        <div className="relative mb-4 mt-2">
          <div className="w-18 h-18 sm:w-20 sm:h-20 rounded-2xl bg-[#4F46E5] text-white flex items-center justify-center border-[1.5px] border-[#1A1A1A] dark:border-white/20 shadow-[3px_3px_0_#1A1A1A] animate-bounce">
            <AlarmClock className="w-9 h-9" />
          </div>
        </div>

        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full border border-rose-500/40 text-rose-500 text-xs label-mono uppercase mb-3">
          <BellRing className="w-3.5 h-3.5 animate-spin" />
          <span>Alarm Ringing</span>
        </div>

        {/* Time Display */}
        <div className="flex items-baseline justify-center gap-2 mb-1">
          <h2 className="text-4xl sm:text-5xl font-bold font-mono-display tracking-tight">
            {formattedTime.time}
          </h2>
          {formattedTime.period && (
            <span className="text-lg sm:text-xl font-bold font-mono-display text-[#4F46E5] dark:text-[#818CF8]">
              {formattedTime.period}
            </span>
          )}
        </div>

        {/* Alarm Label */}
        <p className="font-serif-display text-2xl font-bold mb-5">
          {alarm.label || 'Alarm'}
        </p>

        {/* Snooze Duration Selector Options */}
        <div className="w-full mb-5 p-3.5 rounded-2xl border-[1.5px] border-[#1A1A1A]/20 dark:border-[#F8F7F4]/20">
          <div className="label-mono mb-2">
            Snooze Duration
          </div>
          <div className="grid grid-cols-3 gap-2">
            {[5, 10, 15].map((mins) => (
              <button
                key={mins}
                type="button"
                onClick={() => setSelectedSnooze(mins)}
                className={`py-1.5 px-2 rounded-xl text-xs font-mono-display font-bold border transition-all cursor-pointer ${
                  selectedSnooze === mins
                    ? 'bg-[#4F46E5] text-white border-[#4F46E5]'
                    : 'border-[#1A1A1A]/20 dark:border-[#F8F7F4]/20 opacity-70'
                }`}
              >
                +{mins} min
              </button>
            ))}
          </div>
        </div>

        {/* Primary Action Buttons */}
        <div className="w-full flex flex-col gap-2.5">
          <button
            onClick={handleDismiss}
            className="w-full py-3 px-4 rounded-full bg-rose-600 hover:bg-rose-700 text-white text-xs font-mono-display uppercase tracking-wider border-[1.5px] border-[#1A1A1A] dark:border-white shadow-[3px_3px_0_#1A1A1A] active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Check className="w-4 h-4" />
            <span>Stop Alarm</span>
          </button>

          <button
            onClick={() => handleSnooze(selectedSnooze)}
            className="w-full py-2.5 px-4 rounded-full text-xs font-mono-display uppercase tracking-wider border border-current opacity-70 hover:opacity-100 transition-all active:scale-98 cursor-pointer"
          >
            Snooze for {selectedSnooze} Minutes
          </button>
        </div>
      </div>
    </div>
  );
};
