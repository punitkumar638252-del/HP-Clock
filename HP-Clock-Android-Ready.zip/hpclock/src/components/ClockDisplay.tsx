import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';
import { TimeData, TimeFormat, ThemeMode } from '../types';

interface ClockDisplayProps {
  timeData: TimeData;
  format: TimeFormat;
  theme: ThemeMode;
  showSeconds: boolean;
}

export const ClockDisplay: React.FC<ClockDisplayProps> = ({
  timeData,
  format,
  theme,
  showSeconds,
}) => {
  const [copied, setCopied] = useState(false);
  const isDark = theme === 'dark';

  const handleCopyTime = () => {
    const textToCopy = `${timeData.hoursStr}:${timeData.minutesStr}${
      showSeconds ? `:${timeData.secondsStr}` : ''
    }${timeData.period ? ` ${timeData.period}` : ''} — ${timeData.dayName}, ${timeData.monthName} ${timeData.dayOfMonth}, ${timeData.year} (${timeData.timeZone})`;

    if (navigator.clipboard) {
      navigator.clipboard.writeText(textToCopy);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const secondsNumeric = Number(timeData.secondsStr) || 0;
  const progressPercent = (secondsNumeric / 59) * 100;

  return (
    <div
      id="clock-display-card"
      className="w-full max-w-4xl mx-auto flex flex-col items-center justify-center text-center px-4 py-8 sm:py-14"
    >
      {/* Timezone Pill matching the design HTML */}
      <div
        id="timezone-pill"
        className="label px-3 py-1 rounded-none border border-[#1A1A1A] dark:border-[#F8F7F4]/40 text-[#1A1A1A] dark:text-[#F8F7F4] mb-6 sm:mb-8 transition-colors select-none"
      >
        {timeData.timeZone}
      </div>

      {/* Big Digital Time Display matching .big-time .mono-font */}
      <div id="digital-time-wrapper" className="relative mb-3 sm:mb-4 flex items-center justify-center">
        <div className="big-time mono-font flex items-baseline select-none text-[#1A1A1A] dark:text-[#F8F7F4]">
          <span>{timeData.hoursStr}</span>
          <span className="text-[#B8860B] dark:text-[#D4AF37] opacity-60 mx-1">
            :
          </span>
          <span>{timeData.minutesStr}</span>

          {showSeconds && (
            <>
              <span className="text-[#B8860B] dark:text-[#D4AF37] opacity-60 mx-1">
                :
              </span>
              <span
                id="seconds-display"
                className="text-[#B8860B] dark:text-[#D4AF37]"
              >
                {timeData.secondsStr}
              </span>
            </>
          )}
        </div>

        {format === '12h' && timeData.period && (
          <div
            id="am-pm-badge"
            className="label absolute -right-8 sm:-right-12 top-2 sm:top-4 text-[#B8860B] dark:text-[#D4AF37] font-bold rotate-90 origin-left"
          >
            {timeData.period}
          </div>
        )}
      </div>

      {/* Label under clock */}
      <div className="label text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60 tracking-[0.2em] mb-6">
        Digital Precise Display
      </div>

      {/* Subtle Golden Progress Line */}
      <div
        className="w-full max-w-md h-[1px] bg-[#1A1A1A]/10 dark:bg-[#F8F7F4]/10 mb-6 relative overflow-hidden"
        title="Seconds Progress"
      >
        <div
          id="seconds-progress-bar"
          className="h-full bg-[#B8860B] dark:bg-[#D4AF37] transition-all duration-300"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Date & Copy Row */}
      <div className="flex flex-wrap items-center justify-center gap-3 sm:gap-6 mt-1">
        <span className="font-serif-display text-lg sm:text-xl md:text-2xl text-[#1A1A1A] dark:text-[#F8F7F4]">
          {timeData.dayName}, {timeData.monthName} {timeData.dayOfMonth}, {timeData.year}
        </span>
        <button
          id="copy-time-button"
          onClick={handleCopyTime}
          title="Copy time info"
          className={`px-3 py-1 border transition-all text-xs font-mono-display flex items-center gap-1.5 active:scale-95 cursor-pointer ${
            isDark
              ? 'border-[#F8F7F4]/40 hover:bg-[#F8F7F4] hover:text-[#121214] text-[#F8F7F4]'
              : 'border-[#1A1A1A] hover:bg-[#1A1A1A] hover:text-white text-[#1A1A1A]'
          }`}
        >
          {copied ? (
            <>
              <Check className="w-3 h-3 text-emerald-500" />
              <span>Copied</span>
            </>
          ) : (
            <>
              <Copy className="w-3 h-3 opacity-70" />
              <span>Copy Info</span>
            </>
          )}
        </button>
      </div>
    </div>
  );
};

