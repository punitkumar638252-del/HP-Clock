import React, { useState, useEffect } from 'react';
import { Search, Plus, Trash2, Globe, Sun, Moon, MapPin, X } from 'lucide-react';
import { WorldCity, ThemeMode, TimeFormat } from '../types';
import { soundManager } from '../utils/audioAlert';

interface WorldClockTabProps {
  theme: ThemeMode;
  format: TimeFormat;
  selectedCities: WorldCity[];
  onAddCity: (city: WorldCity) => void;
  onRemoveCity: (id: string) => void;
}

export const AVAILABLE_CITIES: WorldCity[] = [
  { id: 'london', city: 'London', country: 'United Kingdom', timeZone: 'Europe/London' },
  { id: 'new_york', city: 'New York', country: 'United States', timeZone: 'America/New_York' },
  { id: 'tokyo', city: 'Tokyo', country: 'Japan', timeZone: 'Asia/Tokyo' },
  { id: 'paris', city: 'Paris', country: 'France', timeZone: 'Europe/Paris' },
  { id: 'sydney', city: 'Sydney', country: 'Australia', timeZone: 'Australia/Sydney' },
  { id: 'dubai', city: 'Dubai', country: 'United Arab Emirates', timeZone: 'Asia/Dubai' },
  { id: 'singapore', city: 'Singapore', country: 'Singapore', timeZone: 'Asia/Singapore' },
  { id: 'los_angeles', city: 'Los Angeles', country: 'United States', timeZone: 'America/Los_Angeles' },
  { id: 'berlin', city: 'Berlin', country: 'Germany', timeZone: 'Europe/Berlin' },
  { id: 'hong_kong', city: 'Hong Kong', country: 'Hong Kong', timeZone: 'Asia/Hong_Kong' },
  { id: 'mumbai', city: 'Mumbai', country: 'India', timeZone: 'Asia/Kolkata' },
  { id: 'toronto', city: 'Toronto', country: 'Canada', timeZone: 'America/Toronto' },
  { id: 'cairo', city: 'Cairo', country: 'Egypt', timeZone: 'Africa/Cairo' },
  { id: 'sao_paulo', city: 'São Paulo', country: 'Brazil', timeZone: 'America/Sao_Paulo' },
  { id: 'seoul', city: 'Seoul', country: 'South Korea', timeZone: 'Asia/Seoul' },
  { id: 'bangkok', city: 'Bangkok', country: 'Thailand', timeZone: 'Asia/Bangkok' },
  { id: 'auckland', city: 'Auckland', country: 'New Zealand', timeZone: 'Pacific/Auckland' },
  { id: 'honolulu', city: 'Honolulu', country: 'United States', timeZone: 'Pacific/Honolulu' },
  { id: 'madrid', city: 'Madrid', country: 'Spain', timeZone: 'Europe/Madrid' },
  { id: 'rome', city: 'Rome', country: 'Italy', timeZone: 'Europe/Rome' },
  { id: 'chicago', city: 'Chicago', country: 'United States', timeZone: 'America/Chicago' },
  { id: 'beijing', city: 'Beijing', country: 'China', timeZone: 'Asia/Shanghai' },
  { id: 'amsterdam', city: 'Amsterdam', country: 'Netherlands', timeZone: 'Europe/Amsterdam' },
  { id: 'johannesburg', city: 'Johannesburg', country: 'South Africa', timeZone: 'Africa/Johannesburg' },
  { id: 'vancouver', city: 'Vancouver', country: 'Canada', timeZone: 'America/Vancouver' },
  { id: 'buenos_aires', city: 'Buenos Aires', country: 'Argentina', timeZone: 'America/Argentina/Buenos_Aires' },
  { id: 'istanbul', city: 'Istanbul', country: 'Turkey', timeZone: 'Europe/Istanbul' },
];

export const WorldClockTab: React.FC<WorldClockTabProps> = ({
  theme,
  format,
  selectedCities,
  onAddCity,
  onRemoveCity,
}) => {
  const isDark = theme === 'dark';
  const [searchQuery, setSearchQuery] = useState('');
  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [currentTime, setCurrentTime] = useState<Date>(new Date());

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const filteredCities = AVAILABLE_CITIES.filter((c) => {
    const isAlreadyAdded = selectedCities.some((sel) => sel.id === c.id);
    if (isAlreadyAdded) return false;
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      c.city.toLowerCase().includes(q) ||
      c.country.toLowerCase().includes(q) ||
      c.timeZone.toLowerCase().includes(q)
    );
  });

  const getCityTimeInfo = (timeZone: string) => {
    const now = currentTime;

    try {
      const options: Intl.DateTimeFormatOptions = {
        timeZone,
        hour12: format === '12h',
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      };

      const timeString = new Intl.DateTimeFormat('en-US', options).format(now);

      const dateOptions: Intl.DateTimeFormatOptions = {
        timeZone,
        weekday: 'short',
        month: 'short',
        day: 'numeric',
      };
      const dateString = new Intl.DateTimeFormat('en-US', dateOptions).format(now);

      const hourOptions: Intl.DateTimeFormatOptions = {
        timeZone,
        hour: 'numeric',
        hour12: false,
      };
      const cityHour = parseInt(
        new Intl.DateTimeFormat('en-US', hourOptions).format(now),
        10
      );
      const isDay = cityHour >= 6 && cityHour < 18;

      let diffStr = 'Same time';
      try {
        const localDate = new Date(now.toLocaleString('en-US'));
        const cityDate = new Date(now.toLocaleString('en-US', { timeZone }));
        const diffMs = cityDate.getTime() - localDate.getTime();
        const diffTotalMinutes = Math.round(diffMs / 60000);
        const diffHours = Math.floor(Math.abs(diffTotalMinutes) / 60);
        const diffMins = Math.abs(diffTotalMinutes) % 60;

        if (diffTotalMinutes === 0) {
          diffStr = 'Same time';
        } else {
          const isAhead = diffTotalMinutes > 0;
          const sign = isAhead ? '+' : '-';
          const direction = isAhead ? 'ahead' : 'behind';
          if (diffMins === 0) {
            diffStr = `${sign}${diffHours}h ${direction}`;
          } else {
            diffStr = `${sign}${diffHours}h ${diffMins}m ${direction}`;
          }
        }
      } catch (err) {
        diffStr = '';
      }

      return {
        timeString,
        dateString,
        isDay,
        diffStr,
      };
    } catch (e) {
      return {
        timeString: '--:--',
        dateString: '',
        isDay: true,
        diffStr: '',
      };
    }
  };

  return (
    <div id="world-clock-container" className="w-full max-w-2xl mx-auto flex flex-col py-4">
      {/* Header bar */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <span className="label-mono text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60">
            Global Zones
          </span>
          <h2 className="font-serif-display text-2xl sm:text-3xl font-semibold tracking-tight leading-none text-[#1A1A1A] dark:text-[#F8F7F4]">
            World Clock
          </h2>
        </div>

        <button
          id="add-city-button"
          onClick={() => {
            soundManager.playTap();
            setIsSearchModalOpen(true);
          }}
          className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#4F46E5] hover:bg-[#4338CA] text-white text-xs font-mono-display uppercase tracking-wider shadow-[3px_3px_0_#1A1A1A] dark:shadow-[3px_3px_0_#6366F1] border-[1.5px] border-[#1A1A1A] dark:border-white/20 active:scale-95 transition-all cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>Add City</span>
        </button>
      </div>

      {/* Selected Cities List */}
      <div className="space-y-4">
        {selectedCities.length === 0 ? (
          <div
            className={`p-10 text-center rounded-3xl border-[1.5px] ${
              isDark
                ? 'bg-[#18181B] border-[#F8F7F4]/20 text-[#F8F7F4]/60'
                : 'bg-white border-[#1A1A1A] text-[#1A1A1A]/60'
            }`}
          >
            <Globe className="w-8 h-8 text-[#4F46E5] dark:text-[#818CF8] mx-auto mb-3" />
            <h4 className="font-serif-display text-xl text-[#1A1A1A] dark:text-[#F8F7F4] font-semibold">
              No Cities Added
            </h4>
            <p className="text-xs max-w-xs mx-auto mt-1 mb-4">
              Add major international cities to check times across different global meridians.
            </p>
            <button
              onClick={() => setIsSearchModalOpen(true)}
              className="px-4 py-2 rounded-full bg-[#4F46E5] text-white text-xs font-mono-display uppercase border-[1.5px] border-[#1A1A1A] shadow-[2px_2px_0_#1A1A1A] active:scale-95 transition-all inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Browse Cities</span>
            </button>
          </div>
        ) : (
          selectedCities.map((item) => {
            const { timeString, dateString, isDay, diffStr } = getCityTimeInfo(
              item.timeZone
            );

            return (
              <div
                key={item.id}
                id={`world-city-card-${item.id}`}
                className={`flex items-center justify-between p-4 sm:p-6 rounded-2xl border-[1.5px] transition-all duration-300 ${
                  isDark
                    ? 'bg-[#18181B] border-[#F8F7F4]/30 text-[#F8F7F4] shadow-[4px_4px_0_#6366F1]'
                    : 'bg-white border-[#1A1A1A] text-[#1A1A1A] shadow-[4px_4px_0_#1A1A1A]'
                }`}
              >
                {/* Left City Info */}
                <div className="flex flex-col">
                  <div className="flex items-center gap-2">
                    <h3 className="font-serif-display text-xl sm:text-2xl font-bold tracking-tight">
                      {item.city}
                    </h3>
                    {isDay ? (
                      <Sun className="w-4 h-4 text-amber-500 shrink-0" title="Daytime" />
                    ) : (
                      <Moon className="w-4 h-4 text-indigo-400 shrink-0" title="Nighttime" />
                    )}
                  </div>

                  <span className="label-mono text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60">
                    {item.country}
                  </span>

                  <div className="flex items-center gap-2 mt-1 text-xs font-mono-display opacity-75">
                    <span>{dateString}</span>
                    <span>•</span>
                    <span className="text-[#4F46E5] dark:text-[#818CF8] font-bold">
                      {diffStr}
                    </span>
                  </div>
                </div>

                {/* Right Time & Remove */}
                <div className="flex items-center gap-3 sm:gap-4">
                  <span className="text-2xl sm:text-3xl font-bold font-mono-display tracking-tight">
                    {timeString}
                  </span>

                  <button
                    onClick={() => {
                      soundManager.playTap();
                      onRemoveCity(item.id);
                    }}
                    title={`Remove ${item.city}`}
                    className="p-2 rounded-full border border-transparent hover:border-rose-500/50 hover:bg-rose-500/10 text-slate-400 hover:text-rose-500 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add City Search Modal */}
      {isSearchModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div
            className={`w-full max-w-md rounded-3xl p-6 shadow-2xl border-[1.5px] flex flex-col max-h-[85vh] ${
              isDark
                ? 'bg-[#18181B] border-[#F8F7F4]/40 text-[#F8F7F4] shadow-[8px_8px_0_#6366F1]'
                : 'bg-white border-[#1A1A1A] text-[#1A1A1A] shadow-[8px_8px_0_#1A1A1A]'
            }`}
          >
            {/* Modal header */}
            <div className="flex items-center justify-between mb-4 pb-2 border-b border-[#1A1A1A]/10 dark:border-[#F8F7F4]/10">
              <div className="flex items-center gap-2">
                <Globe className="w-5 h-5 text-[#4F46E5] dark:text-[#818CF8]" />
                <h3 className="font-serif-display text-xl font-bold">Select World City</h3>
              </div>
              <button
                onClick={() => setIsSearchModalOpen(false)}
                className="w-8 h-8 rounded-full border border-transparent hover:border-current flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Search Input */}
            <div className="relative mb-4">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-3" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search city, country or timezone..."
                autoFocus
                className="w-full pl-10 pr-4 py-2.5 rounded-full border-[1.5px] border-[#1A1A1A]/20 dark:border-[#F8F7F4]/20 text-sm focus:outline-none focus:border-[#4F46E5] bg-transparent font-sans"
              />
            </div>

            {/* City List */}
            <div className="flex-1 overflow-y-auto divide-y divide-[#1A1A1A]/10 dark:divide-[#F8F7F4]/10 pr-1">
              {filteredCities.length === 0 ? (
                <div className="text-center py-8 text-xs label-mono text-slate-400">
                  No matching cities found.
                </div>
              ) : (
                filteredCities.map((c) => {
                  const now = new Date();
                  const sampleTime = new Intl.DateTimeFormat('en-US', {
                    timeZone: c.timeZone,
                    hour: '2-digit',
                    minute: '2-digit',
                    hour12: format === '12h',
                  }).format(now);

                  return (
                    <button
                      key={c.id}
                      onClick={() => {
                        soundManager.playChime();
                        onAddCity(c);
                        setIsSearchModalOpen(false);
                        setSearchQuery('');
                      }}
                      className={`w-full flex items-center justify-between py-3 px-2 rounded-xl text-left transition-colors cursor-pointer ${
                        isDark ? 'hover:bg-white/5' : 'hover:bg-black/5'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <MapPin className="w-4 h-4 text-[#4F46E5] dark:text-[#818CF8] shrink-0" />
                        <div>
                          <div className="font-serif-display text-base font-bold">{c.city}</div>
                          <div className="label-mono text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60">{c.country}</div>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-sm font-bold font-mono-display text-[#4F46E5] dark:text-[#818CF8]">
                          {sampleTime}
                        </span>
                        <div className="label-mono opacity-50">
                          {c.timeZone.split('/')[1]?.replace('_', ' ')}
                        </div>
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
