import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Flag } from 'lucide-react';
import { ThemeMode, LapRecord } from '../types';
import { soundManager } from '../utils/audioAlert';

interface StopwatchTabProps {
  theme: ThemeMode;
  onRunningChange?: (isRunning: boolean) => void;
}

export const StopwatchTab: React.FC<StopwatchTabProps> = ({
  theme,
  onRunningChange,
}) => {
  const isDark = theme === 'dark';

  const [elapsedTime, setElapsedTime] = useState(0); // in ms
  const [isRunning, setIsRunning] = useState(false);
  const [laps, setLaps] = useState<LapRecord[]>([]);

  const intervalRef = useRef<any>(null);
  const startTimeRef = useRef<number>(0);
  const lastLapTimeRef = useRef<number>(0);

  useEffect(() => {
    onRunningChange?.(isRunning);
  }, [isRunning, onRunningChange]);

  useEffect(() => {
    if (isRunning) {
      startTimeRef.current = Date.now() - elapsedTime;
      intervalRef.current = setInterval(() => {
        setElapsedTime(Date.now() - startTimeRef.current);
      }, 10);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isRunning]);

  const handleStart = () => {
    soundManager.playTap();
    setIsRunning(true);
  };

  const handlePause = () => {
    soundManager.playTap();
    setIsRunning(false);
  };

  const handleReset = () => {
    soundManager.playTap();
    setIsRunning(false);
    setElapsedTime(0);
    setLaps([]);
    lastLapTimeRef.current = 0;
  };

  const handleLap = () => {
    soundManager.playTap();
    const currentLapTime = elapsedTime - lastLapTimeRef.current;
    lastLapTimeRef.current = elapsedTime;

    const newLap: LapRecord = {
      lapNumber: laps.length + 1,
      time: elapsedTime,
      lapDuration: currentLapTime,
    };

    setLaps((prev) => [newLap, ...prev]);
  };

  const formatTimeParts = (ms: number) => {
    const hours = Math.floor(ms / 3600000);
    const minutes = Math.floor((ms % 3600000) / 60000);
    const seconds = Math.floor((ms % 60000) / 1000);
    const milliseconds = Math.floor((ms % 1000) / 10);

    return {
      hours: hours > 0 ? String(hours).padStart(2, '0') : null,
      minutes: String(minutes).padStart(2, '0'),
      seconds: String(seconds).padStart(2, '0'),
      milliseconds: String(milliseconds).padStart(2, '0'),
    };
  };

  const currentFormatted = formatTimeParts(elapsedTime);

  let fastestLapNumber: number | null = null;
  let slowestLapNumber: number | null = null;

  if (laps.length >= 2) {
    let minDuration = Infinity;
    let maxDuration = -1;
    laps.forEach((l) => {
      if (l.lapDuration < minDuration) {
        minDuration = l.lapDuration;
        fastestLapNumber = l.lapNumber;
      }
      if (l.lapDuration > maxDuration) {
        maxDuration = l.lapDuration;
        slowestLapNumber = l.lapNumber;
      }
    });
  }

  const secondsFraction = (elapsedTime % 60000) / 60000;
  const rotationDegrees = secondsFraction * 360;

  return (
    <div id="stopwatch-tab-container" className="w-full max-w-xl mx-auto flex flex-col items-center py-4">
      {/* Stopwatch Main Dial Card */}
      <div
        id="stopwatch-card"
        className={`relative w-full rounded-3xl p-6 sm:p-10 flex flex-col items-center justify-center border-[1.5px] transition-all duration-300 ${
          isDark
            ? 'bg-[#18181B] border-[#F8F7F4]/30 shadow-[6px_6px_0_#6366F1] text-[#F8F7F4]'
            : 'bg-white border-[#1A1A1A] shadow-[6px_6px_0_#1A1A1A] text-[#1A1A1A]'
        }`}
      >
          <span className="label text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60 mb-2">
            Precision Chronograph
          </span>

          {/* Visual Dial Ring */}
          <div className="relative w-60 h-60 sm:w-72 sm:h-72 flex items-center justify-center my-3">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
              <circle
                cx="50"
                cy="50"
                r="44"
                className={isDark ? 'stroke-white/10' : 'stroke-black/10'}
                strokeWidth="2.5"
                fill="none"
              />
              <circle
                cx="50"
                cy="50"
                r="44"
                className="stroke-[#B8860B] dark:stroke-[#D4AF37] transition-all duration-75"
                strokeWidth="3.5"
                strokeDasharray="276.46"
                strokeDashoffset={276.46 - 276.46 * secondsFraction}
                strokeLinecap="round"
                fill="none"
              />
            </svg>

            {/* Cursor Indicator */}
            <div
              className="absolute inset-0 flex items-start justify-center pointer-events-none transition-transform duration-75"
              style={{ transform: `rotate(${rotationDegrees}deg)` }}
            >
              <div className="w-3 h-3 rounded-full bg-[#B8860B] dark:bg-[#D4AF37] shadow-md -mt-1.5" />
            </div>

            {/* Time digits in center */}
            <div className="absolute inset-0 flex flex-col items-center justify-center select-none font-mono-display">
              <div className="flex items-baseline">
                {currentFormatted.hours && (
                  <>
                    <span className="text-3xl sm:text-4xl font-bold">
                      {currentFormatted.hours}
                    </span>
                    <span className="text-xl sm:text-2xl font-light text-[#B8860B] dark:text-[#D4AF37] mx-0.5">
                      :
                    </span>
                  </>
                )}
                <span className="text-4xl sm:text-5xl font-bold tracking-tight">
                  {currentFormatted.minutes}
                </span>
                <span className="text-2xl sm:text-3xl font-light text-[#B8860B] dark:text-[#D4AF37] mx-0.5">
                  :
                </span>
                <span className="text-4xl sm:text-5xl font-bold tracking-tight">
                  {currentFormatted.seconds}
                </span>
              </div>

              {/* Milliseconds Badge */}
              <div className="mt-2">
                <span className="text-sm sm:text-base font-bold text-[#B8860B] dark:text-[#D4AF37] border border-[#B8860B]/40 dark:border-[#D4AF37]/40 px-3 py-0.5 rounded-full font-mono-display">
                  .{currentFormatted.milliseconds}s
                </span>
              </div>
            </div>
          </div>

          {/* Action Controls */}
          <div className="w-full flex items-center justify-center gap-4 mt-6">
            {/* Lap / Reset button */}
            <button
              id="stopwatch-lap-reset-btn"
              onClick={isRunning ? handleLap : handleReset}
              disabled={!isRunning && elapsedTime === 0}
              className={`w-18 h-18 sm:w-20 sm:h-20 rounded-2xl flex flex-col items-center justify-center gap-1 text-xs font-mono-display uppercase tracking-wider border transition-all active:scale-95 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed ${
                isDark
                  ? 'bg-[#121214] border-[#F8F7F4]/30 text-[#F8F7F4] hover:bg-[#F8F7F4]/10'
                  : 'bg-[#F8F7F4] border-[#1A1A1A] text-[#1A1A1A] hover:bg-[#1A1A1A]/5'
              }`}
            >
              {isRunning ? (
                <>
                  <Flag className="w-5 h-5 text-[#B8860B] dark:text-[#D4AF37]" />
                  <span>Lap</span>
                </>
              ) : (
                <>
                  <RotateCcw className="w-5 h-5 opacity-70" />
                  <span>Reset</span>
                </>
              )}
            </button>

            {/* Start / Pause button */}
            <button
              id="stopwatch-start-pause-btn"
              onClick={isRunning ? handlePause : handleStart}
              className={`w-20 h-20 sm:w-24 sm:h-24 rounded-2xl flex flex-col items-center justify-center gap-1 text-xs font-mono-display uppercase tracking-wider border shadow-[3px_3px_0_#1A1A1A] dark:shadow-[3px_3px_0_#D4AF37] active:scale-95 transition-all cursor-pointer ${
                isRunning
                  ? 'bg-amber-600 hover:bg-amber-700 text-white border-[#1A1A1A] dark:border-white/20'
                  : 'bg-[#B8860B] hover:bg-[#996F08] text-white border-[#1A1A1A] dark:border-white/20'
              }`}
            >
              {isRunning ? (
                <>
                  <Pause className="w-7 h-7 fill-current" />
                  <span>Pause</span>
                </>
              ) : (
                <>
                  <Play className="w-7 h-7 ml-1 fill-current" />
                  <span>{elapsedTime > 0 ? 'Resume' : 'Start'}</span>
                </>
              )}
            </button>
          </div>
      </div>

      {/* Lap Times List */}
      {laps.length > 0 && (
        <div
          id="stopwatch-laps-section"
          className={`w-full mt-6 rounded-2xl p-5 border-[1.5px] transition-all ${
            isDark
              ? 'bg-[#18181B] border-[#F8F7F4]/30 text-[#F8F7F4]'
              : 'bg-white border-[#1A1A1A] text-[#1A1A1A]'
          }`}
        >
          <div className="flex items-center justify-between text-xs font-mono-display uppercase tracking-wider opacity-60 pb-3 border-b border-[#1A1A1A]/10 dark:border-[#F8F7F4]/10">
            <span>Lap #</span>
            <span>Split Time</span>
            <span>Total Time</span>
          </div>

          <div className="max-h-56 overflow-y-auto divide-y divide-[#1A1A1A]/10 dark:divide-[#F8F7F4]/10 mt-1">
            {laps.map((lap) => {
              const lapParts = formatTimeParts(lap.lapDuration);
              const totalParts = formatTimeParts(lap.time);
              const isFastest = lap.lapNumber === fastestLapNumber;
              const isSlowest = lap.lapNumber === slowestLapNumber;

              return (
                <div
                  key={lap.lapNumber}
                  className={`flex items-center justify-between py-3 text-xs sm:text-sm font-mono-display ${
                    isFastest
                      ? 'text-emerald-600 dark:text-emerald-400 font-bold'
                      : isSlowest
                      ? 'text-rose-600 dark:text-rose-400 font-bold'
                      : ''
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span>Lap {String(lap.lapNumber).padStart(2, '0')}</span>
                    {isFastest && (
                      <span className="text-[10px] border border-emerald-500/30 px-1.5 py-0.2 rounded-full text-emerald-600 dark:text-emerald-400">
                        Fastest
                      </span>
                    )}
                    {isSlowest && (
                      <span className="text-[10px] border border-rose-500/30 px-1.5 py-0.2 rounded-full text-rose-600 dark:text-rose-400">
                        Slowest
                      </span>
                    )}
                  </div>

                  <span className="tabular-nums opacity-80">
                    +{lapParts.minutes}:{lapParts.seconds}.{lapParts.milliseconds}
                  </span>

                  <span className="tabular-nums font-bold">
                    {totalParts.minutes}:{totalParts.seconds}.{totalParts.milliseconds}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
};
