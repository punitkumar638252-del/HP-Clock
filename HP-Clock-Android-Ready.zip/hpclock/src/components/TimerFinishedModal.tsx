import React, { useEffect } from 'react';
import { Hourglass, Check, RotateCcw } from 'lucide-react';
import { ThemeMode } from '../types';
import { soundManager } from '../utils/audioAlert';

interface TimerFinishedModalProps {
  theme: ThemeMode;
  onDismiss: () => void;
  onRestart: () => void;
}

export const TimerFinishedModal: React.FC<TimerFinishedModalProps> = ({
  theme,
  onDismiss,
  onRestart,
}) => {
  const isDark = theme === 'dark';

  useEffect(() => {
    soundManager.startAlarmTone();
    return () => {
      soundManager.stopAlarmTone();
    };
  }, []);

  const handleDismiss = () => {
    soundManager.stopAlarmTone();
    onDismiss();
  };

  const handleRestart = () => {
    soundManager.stopAlarmTone();
    onRestart();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-in fade-in zoom-in-95 duration-200">
      <div
        className={`w-full max-w-sm rounded-3xl p-6 sm:p-8 shadow-2xl border-[1.5px] flex flex-col items-center text-center ${
          isDark
            ? 'bg-[#18181B] border-[#F8F7F4]/40 text-[#F8F7F4] shadow-[8px_8px_0_#6366F1]'
            : 'bg-white border-[#1A1A1A] text-[#1A1A1A] shadow-[8px_8px_0_#1A1A1A]'
        }`}
      >
        {/* Timer Finished Icon */}
        <div className="relative mb-5">
          <div className="w-18 h-18 rounded-2xl bg-[#4F46E5] text-white flex items-center justify-center border-[1.5px] border-[#1A1A1A] dark:border-white shadow-[3px_3px_0_#1A1A1A] animate-bounce">
            <Hourglass className="w-9 h-9" />
          </div>
        </div>

        <span className="label-mono text-[#4F46E5] dark:text-[#818CF8] mb-1">
          Time's Up!
        </span>

        <h3 className="font-serif-display text-2xl sm:text-3xl font-bold tracking-tight mb-2">
          Timer Finished
        </h3>

        <p className="label-mono opacity-70 mb-6">
          Your countdown timer has reached zero.
        </p>

        {/* Action buttons */}
        <div className="w-full flex flex-col gap-2.5">
          <button
            onClick={handleDismiss}
            className="w-full py-3 px-4 rounded-full bg-[#4F46E5] hover:bg-[#4338CA] text-white text-xs font-mono-display uppercase tracking-wider border-[1.5px] border-[#1A1A1A] dark:border-white shadow-[3px_3px_0_#1A1A1A] active:scale-98 transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Check className="w-4 h-4" />
            <span>Dismiss</span>
          </button>

          <button
            onClick={handleRestart}
            className="w-full py-2.5 px-4 rounded-full text-xs font-mono-display uppercase tracking-wider border border-current opacity-70 hover:opacity-100 transition-all active:scale-98 flex items-center justify-center gap-2 cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Restart Timer</span>
          </button>
        </div>
      </div>
    </div>
  );
};
