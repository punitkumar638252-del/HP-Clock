import React, { useState, useEffect, useMemo } from 'react';
import {
  Plus,
  Bell,
  Trash2,
  Check,
  Volume2,
  X,
  Edit3,
  ChevronUp,
  ChevronDown,
  AlertTriangle,
  AlarmClock,
} from 'lucide-react';
import { AlarmItem, ThemeMode, TimeFormat } from '../types';
import { soundManager } from '../utils/audioAlert';
import {
  formatAlarmTime,
  getNextTriggerDate,
  getTimeUntilAlarm,
  sortAlarmsByNextTrigger,
} from '../utils/alarmUtils';

interface AlarmTabProps {
  alarms: AlarmItem[];
  onAddAlarm: (alarm: Omit<AlarmItem, 'id' | 'createdAt'>) => void;
  onEditAlarm?: (id: string, alarm: Omit<AlarmItem, 'id' | 'createdAt'>) => void;
  onToggleAlarm: (id: string) => void;
  onDeleteAlarm: (id: string) => void;
  theme: ThemeMode;
  format: TimeFormat;
}

const DAY_LABELS = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
const QUICK_LABELS = ['Wake Up', 'Work', 'Workout', 'Medication', 'Study', 'Meeting', 'Nap'];

export const AlarmTab: React.FC<AlarmTabProps> = ({
  alarms,
  onAddAlarm,
  onEditAlarm,
  onToggleAlarm,
  onDeleteAlarm,
  theme,
  format,
}) => {
  const isDark = theme === 'dark';

  // Modal states
  const [modalOpen, setModalOpen] = useState(false);
  const [editingAlarmId, setEditingAlarmId] = useState<string | null>(null);
  const [alarmToDelete, setAlarmToDelete] = useState<AlarmItem | null>(null);

  // Form states
  const [hour, setHour] = useState<number>(7);
  const [minute, setMinute] = useState<number>(0);
  const [period, setPeriod] = useState<'AM' | 'PM'>('AM');
  const [label, setLabel] = useState<string>('Wake Up');
  const [repeatDays, setRepeatDays] = useState<number[]>([1, 2, 3, 4, 5]);
  const [repeatMode, setRepeatMode] = useState<'everyday' | 'weekdays' | 'weekends' | 'custom' | 'once'>('weekdays');
  const [snoozeDuration, setSnoozeDuration] = useState<number>(5);

  // Live ticker for next alarm calculations
  const [currentTick, setCurrentTick] = useState<Date>(new Date());
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTick(new Date());
    }, 10000);
    return () => clearInterval(timer);
  }, []);

  const sortedAlarms = useMemo(() => {
    return sortAlarmsByNextTrigger(alarms, currentTick);
  }, [alarms, currentTick]);

  const updateRepeatModeFromDays = (days: number[]) => {
    if (days.length === 0) {
      setRepeatMode('once');
    } else if (days.length === 7) {
      setRepeatMode('everyday');
    } else if (
      days.length === 5 &&
      [1, 2, 3, 4, 5].every((d) => days.includes(d))
    ) {
      setRepeatMode('weekdays');
    } else if (
      days.length === 2 &&
      [0, 6].every((d) => days.includes(d))
    ) {
      setRepeatMode('weekends');
    } else {
      setRepeatMode('custom');
    }
  };

  const handleOpenAdd = () => {
    soundManager.playTap();
    setEditingAlarmId(null);
    const now = new Date();
    let currentH = now.getHours();
    let currentM = (now.getMinutes() + 10) % 60;

    if (format === '12h') {
      setPeriod(currentH >= 12 ? 'PM' : 'AM');
      let h12 = currentH % 12;
      if (h12 === 0) h12 = 12;
      setHour(h12);
    } else {
      setHour(currentH);
    }
    setMinute(currentM);
    setLabel('Morning Alarm');
    setRepeatDays([1, 2, 3, 4, 5]);
    setRepeatMode('weekdays');
    setSnoozeDuration(5);
    setModalOpen(true);
  };

  const handleOpenEdit = (alarm: AlarmItem) => {
    soundManager.playTap();
    setEditingAlarmId(alarm.id);
    const [h24Str, mStr] = alarm.time.split(':');
    let h24 = parseInt(h24Str, 10);
    let m = parseInt(mStr, 10);

    if (format === '12h') {
      setPeriod(h24 >= 12 ? 'PM' : 'AM');
      let h12 = h24 % 12;
      if (h12 === 0) h12 = 12;
      setHour(h12);
    } else {
      setHour(h24);
    }
    setMinute(m);
    setLabel(alarm.label);
    const days = alarm.repeatDays || [];
    setRepeatDays(days);
    updateRepeatModeFromDays(days);
    setSnoozeDuration(alarm.snoozeDuration || 5);
    setModalOpen(true);
  };

  const handleSelectPresetSchedule = (mode: 'everyday' | 'weekdays' | 'weekends' | 'once') => {
    soundManager.playTap();
    setRepeatMode(mode);
    switch (mode) {
      case 'everyday':
        setRepeatDays([0, 1, 2, 3, 4, 5, 6]);
        break;
      case 'weekdays':
        setRepeatDays([1, 2, 3, 4, 5]);
        break;
      case 'weekends':
        setRepeatDays([0, 6]);
        break;
      case 'once':
        setRepeatDays([]);
        break;
    }
  };

  const handleCustomDayToggle = (dayIndex: number) => {
    soundManager.playTap();
    let newDays: number[];
    if (repeatDays.includes(dayIndex)) {
      newDays = repeatDays.filter((d) => d !== dayIndex);
    } else {
      newDays = [...repeatDays, dayIndex].sort((a, b) => a - b);
    }
    setRepeatDays(newDays);
    updateRepeatModeFromDays(newDays);
  };

  const handleSaveAlarm = (e: React.FormEvent) => {
    e.preventDefault();
    soundManager.playChime();

    let final24Hour = hour;
    if (format === '12h') {
      if (period === 'PM' && hour < 12) final24Hour = hour + 12;
      if (period === 'AM' && hour === 12) final24Hour = 0;
    }

    const timeStr = `${String(final24Hour).padStart(2, '0')}:${String(
      minute
    ).padStart(2, '0')}`;

    const alarmData = {
      time: timeStr,
      label: label.trim() || 'Alarm',
      enabled: true,
      repeatDays,
      snoozeDuration,
    };

    if (editingAlarmId && onEditAlarm) {
      onEditAlarm(editingAlarmId, alarmData);
    } else {
      onAddAlarm(alarmData);
    }

    setModalOpen(false);
    setEditingAlarmId(null);
  };

  const incrementHour = () => {
    soundManager.playTap();
    if (format === '12h') {
      setHour((prev) => (prev % 12) + 1);
    } else {
      setHour((prev) => (prev + 1) % 24);
    }
  };

  const decrementHour = () => {
    soundManager.playTap();
    if (format === '12h') {
      setHour((prev) => (prev === 1 ? 12 : prev - 1));
    } else {
      setHour((prev) => (prev === 0 ? 23 : prev - 1));
    }
  };

  const incrementMinute = () => {
    soundManager.playTap();
    setMinute((prev) => (prev + 1) % 60);
  };

  const decrementMinute = () => {
    soundManager.playTap();
    setMinute((prev) => (prev === 0 ? 59 : prev - 1));
  };

  const nextAlarmInfo = useMemo(() => {
    const activeAlarms = alarms.filter((a) => a.enabled);
    if (activeAlarms.length === 0) return null;

    let earliestTime = Number.MAX_SAFE_INTEGER;
    let earliestAlarm: AlarmItem | null = null;
    let earliestDate: Date | null = null;

    for (const al of activeAlarms) {
      const nextDate = getNextTriggerDate(al, currentTick);
      if (nextDate && nextDate.getTime() < earliestTime) {
        earliestTime = nextDate.getTime();
        earliestAlarm = al;
        earliestDate = nextDate;
      }
    }

    if (!earliestAlarm || !earliestDate) return null;

    const until = getTimeUntilAlarm(earliestAlarm, currentTick);
    if (!until) return null;

    const formatted = formatAlarmTime(earliestAlarm.time, format);

    const isToday = earliestDate.toDateString() === currentTick.toDateString();
    const tomorrow = new Date(currentTick);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const isTomorrow = earliestDate.toDateString() === tomorrow.toDateString();

    let dayPrefix = '';
    if (isToday) dayPrefix = 'Today';
    else if (isTomorrow) dayPrefix = 'Tomorrow';
    else dayPrefix = DAY_LABELS[earliestDate.getDay()];

    return {
      alarm: earliestAlarm,
      untilText: until.text,
      targetDay: dayPrefix,
      targetTime: `${formatted.time} ${formatted.period}`.trim(),
    };
  }, [alarms, currentTick, format]);

  const formatScheduleBadge = (days: number[]) => {
    if (!days || days.length === 0) return 'Once';
    if (days.length === 7) return 'Every day';
    if (days.length === 5 && [1, 2, 3, 4, 5].every((d) => days.includes(d)))
      return 'Weekdays';
    if (days.length === 2 && [0, 6].every((d) => days.includes(d)))
      return 'Weekends';
    return days.map((d) => DAY_LABELS[d]).join(', ');
  };

  return (
    <div className="w-full max-w-2xl mx-auto flex flex-col py-4 animate-in fade-in duration-300">
      {/* Header Controls */}
      <div className="w-full flex items-center justify-between mb-6">
        <div>
          <span className="label-mono text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60">
            Wake Scheduling
          </span>
          <h2 className="font-serif-display text-2xl sm:text-3xl font-semibold tracking-tight leading-none text-[#1A1A1A] dark:text-[#F8F7F4]">
            Alarms
          </h2>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => soundManager.playChime()}
            title="Test alarm sound"
            className={`p-2.5 rounded-full border-[1.5px] text-xs flex items-center gap-1.5 transition-colors cursor-pointer active:scale-95 ${
              isDark
                ? 'bg-[#18181B] border-[#F8F7F4]/30 text-[#F8F7F4] hover:bg-white/5'
                : 'bg-white border-[#1A1A1A] text-[#1A1A1A] hover:bg-black/5'
            }`}
          >
            <Volume2 className="w-4 h-4 text-[#4F46E5] dark:text-[#818CF8]" />
            <span className="hidden sm:inline font-mono-display text-xs">Test Tone</span>
          </button>

          <button
            id="add-alarm-button"
            onClick={handleOpenAdd}
            className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-[#4F46E5] hover:bg-[#4338CA] text-white text-xs font-mono-display uppercase tracking-wider shadow-[3px_3px_0_#1A1A1A] dark:shadow-[3px_3px_0_#6366F1] border-[1.5px] border-[#1A1A1A] dark:border-white/20 active:scale-95 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Add Alarm</span>
          </button>
        </div>
      </div>

      {/* Next Alarm Banner */}
      {nextAlarmInfo && (
        <div
          className={`w-full p-4 mb-6 rounded-2xl flex items-center justify-between border-[1.5px] transition-all ${
            isDark
              ? 'bg-[#18181B] border-[#818CF8]/50 text-[#F8F7F4] shadow-[4px_4px_0_#6366F1]'
              : 'bg-white border-[#4F46E5] text-[#1A1A1A] shadow-[4px_4px_0_#4F46E5]'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-full bg-[#4F46E5]/10 text-[#4F46E5] dark:text-[#818CF8]">
              <Bell className="w-5 h-5 animate-bounce" />
            </div>
            <div>
              <div className="font-serif-display text-base sm:text-lg font-bold">
                Next alarm {nextAlarmInfo.untilText} ({nextAlarmInfo.targetDay} at{' '}
                {nextAlarmInfo.targetTime})
              </div>
              <div className="label-mono opacity-70">
                {nextAlarmInfo.alarm.label || 'Alarm'}
              </div>
            </div>
          </div>

          <span className="label-mono px-2.5 py-1 rounded-full border border-[#4F46E5]/30 text-[#4F46E5] dark:text-[#818CF8]">
            Upcoming
          </span>
        </div>
      )}

      {/* Add / Edit Alarm Modal Form */}
      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div
            className={`w-full max-w-md rounded-3xl p-6 shadow-2xl border-[1.5px] max-h-[90vh] overflow-y-auto ${
              isDark
                ? 'bg-[#18181B] border-[#F8F7F4]/40 text-[#F8F7F4] shadow-[8px_8px_0_#6366F1]'
                : 'bg-white border-[#1A1A1A] text-[#1A1A1A] shadow-[8px_8px_0_#1A1A1A]'
            }`}
          >
            <div className="flex items-center justify-between mb-5 pb-3 border-b border-[#1A1A1A]/10 dark:border-[#F8F7F4]/10">
              <div className="flex items-center gap-2.5">
                <AlarmClock className="w-5 h-5 text-[#4F46E5] dark:text-[#818CF8]" />
                <div>
                  <h3 className="font-serif-display text-xl font-bold">
                    {editingAlarmId ? 'Edit Alarm' : 'Set New Alarm'}
                  </h3>
                </div>
              </div>
              <button
                onClick={() => setModalOpen(false)}
                className="w-8 h-8 rounded-full border border-transparent hover:border-current flex items-center justify-center cursor-pointer"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleSaveAlarm} className="space-y-4">
              {/* Interactive Time Pickers with Up/Down Spinners */}
              <div className="flex items-center justify-center gap-3 sm:gap-4 p-4 rounded-2xl border-[1.5px] border-[#1A1A1A]/20 dark:border-[#F8F7F4]/20">
                {/* Hours Spinner */}
                <div className="flex flex-col items-center">
                  <button
                    type="button"
                    onClick={incrementHour}
                    className="p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 active:scale-95 cursor-pointer"
                  >
                    <ChevronUp className="w-5 h-5" />
                  </button>

                  <input
                    type="number"
                    min={format === '12h' ? 1 : 0}
                    max={format === '12h' ? 12 : 23}
                    value={String(hour).padStart(2, '0')}
                    onChange={(e) => {
                      const v = Number(e.target.value);
                      if (!isNaN(v)) {
                        if (format === '12h') {
                          if (v >= 1 && v <= 12) setHour(v);
                        } else {
                          if (v >= 0 && v <= 23) setHour(v);
                        }
                      }
                    }}
                    className="w-16 text-center text-3xl sm:text-4xl font-bold font-mono-display bg-transparent rounded-lg py-1 focus:outline-none"
                  />

                  <button
                    type="button"
                    onClick={decrementHour}
                    className="p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 active:scale-95 cursor-pointer"
                  >
                    <ChevronDown className="w-5 h-5" />
                  </button>
                  <span className="label-mono mt-1">
                    Hour
                  </span>
                </div>

                <span className="text-3xl font-bold pb-5">:</span>

                {/* Minutes Spinner */}
                <div className="flex flex-col items-center">
                  <button
                    type="button"
                    onClick={incrementMinute}
                    className="p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 active:scale-95 cursor-pointer"
                  >
                    <ChevronUp className="w-5 h-5" />
                  </button>

                  <input
                    type="number"
                    min={0}
                    max={59}
                    value={String(minute).padStart(2, '0')}
                    onChange={(e) => {
                      const v = Number(e.target.value);
                      if (!isNaN(v) && v >= 0 && v <= 59) {
                        setMinute(v);
                      }
                    }}
                    className="w-16 text-center text-3xl sm:text-4xl font-bold font-mono-display bg-transparent rounded-lg py-1 focus:outline-none"
                  />

                  <button
                    type="button"
                    onClick={decrementMinute}
                    className="p-1 rounded-lg hover:bg-black/5 dark:hover:bg-white/5 active:scale-95 cursor-pointer"
                  >
                    <ChevronDown className="w-5 h-5" />
                  </button>
                  <span className="label-mono mt-1">
                    Minute
                  </span>
                </div>

                {/* 12h AM/PM selector */}
                {format === '12h' && (
                  <div className="flex flex-col gap-1.5 pb-5 ml-2">
                    <button
                      type="button"
                      onClick={() => {
                        soundManager.playTap();
                        setPeriod('AM');
                      }}
                      className={`px-3.5 py-1.5 text-xs font-bold font-mono-display rounded-xl border-[1.5px] transition-all cursor-pointer ${
                        period === 'AM'
                          ? 'bg-[#4F46E5] text-white border-[#1A1A1A] dark:border-white shadow-[2px_2px_0_#1A1A1A]'
                          : 'border-[#1A1A1A]/20 dark:border-[#F8F7F4]/20 opacity-60'
                      }`}
                    >
                      AM
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        soundManager.playTap();
                        setPeriod('PM');
                      }}
                      className={`px-3.5 py-1.5 text-xs font-bold font-mono-display rounded-xl border-[1.5px] transition-all cursor-pointer ${
                        period === 'PM'
                          ? 'bg-[#4F46E5] text-white border-[#1A1A1A] dark:border-white shadow-[2px_2px_0_#1A1A1A]'
                          : 'border-[#1A1A1A]/20 dark:border-[#F8F7F4]/20 opacity-60'
                      }`}
                    >
                      PM
                    </button>
                  </div>
                )}
              </div>

              {/* Label & Quick Suggestions */}
              <div>
                <label className="label-mono block mb-1.5">
                  Alarm Name / Label
                </label>
                <input
                  type="text"
                  value={label}
                  onChange={(e) => setLabel(e.target.value)}
                  placeholder="e.g. Wake Up, Work, Medication"
                  maxLength={35}
                  className="w-full px-3.5 py-2.5 rounded-xl border-[1.5px] border-[#1A1A1A]/20 dark:border-[#F8F7F4]/20 text-sm focus:outline-none focus:border-[#4F46E5] bg-transparent"
                />

                <div className="flex flex-wrap gap-1.5 mt-2">
                  {QUICK_LABELS.map((tag) => (
                    <button
                      key={tag}
                      type="button"
                      onClick={() => {
                        soundManager.playTap();
                        setLabel(tag);
                      }}
                      className={`text-xs font-mono-display px-2.5 py-1 rounded-full border transition-all cursor-pointer ${
                        label === tag
                          ? 'bg-[#4F46E5] text-white border-[#4F46E5]'
                          : 'border-[#1A1A1A]/20 dark:border-[#F8F7F4]/20 opacity-60 hover:opacity-100'
                      }`}
                    >
                      {tag}
                    </button>
                  ))}
                </div>
              </div>

              {/* Repeat Schedule Selector */}
              <div>
                <label className="label-mono block mb-2">
                  Repeat Schedule
                </label>

                <div className="grid grid-cols-4 gap-1.5 mb-2.5">
                  {[
                    { id: 'everyday', label: 'Every day' },
                    { id: 'weekdays', label: 'Weekdays' },
                    { id: 'weekends', label: 'Weekends' },
                    { id: 'once', label: 'Once' },
                  ].map((preset) => (
                    <button
                      key={preset.id}
                      type="button"
                      onClick={() =>
                        handleSelectPresetSchedule(
                          preset.id as 'everyday' | 'weekdays' | 'weekends' | 'once'
                        )
                      }
                      className={`py-1.5 px-1 text-center text-xs font-mono-display font-semibold rounded-xl border transition-all cursor-pointer ${
                        repeatMode === preset.id
                          ? 'bg-[#4F46E5] text-white border-[#1A1A1A] dark:border-white shadow-[2px_2px_0_#1A1A1A]'
                          : 'border-[#1A1A1A]/20 dark:border-[#F8F7F4]/20 opacity-60'
                      }`}
                    >
                      {preset.label}
                    </button>
                  ))}
                </div>

                {/* Custom Individual Day Chips */}
                <div className="p-2.5 rounded-2xl border border-[#1A1A1A]/20 dark:border-[#F8F7F4]/20">
                  <div className="label-mono mb-1.5">
                    Custom Days
                  </div>
                  <div className="grid grid-cols-7 gap-1">
                    {DAY_LABELS.map((day, idx) => {
                      const isSelected = repeatDays.includes(idx);
                      return (
                        <button
                          key={day}
                          type="button"
                          onClick={() => handleCustomDayToggle(idx)}
                          className={`py-2 text-[11px] font-mono-display font-bold rounded-xl transition-all cursor-pointer ${
                            isSelected
                              ? 'bg-[#4F46E5] text-white shadow-sm'
                              : 'border border-[#1A1A1A]/20 dark:border-[#F8F7F4]/20 opacity-60'
                          }`}
                        >
                          {day}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Snooze Duration */}
              <div>
                <label className="label-mono block mb-1.5">
                  Snooze Duration
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {[5, 10, 15].map((mins) => (
                    <button
                      key={mins}
                      type="button"
                      onClick={() => {
                        soundManager.playTap();
                        setSnoozeDuration(mins);
                      }}
                      className={`py-2 text-xs font-mono-display font-bold rounded-xl border transition-all cursor-pointer ${
                        snoozeDuration === mins
                          ? 'bg-[#4F46E5] text-white border-[#1A1A1A] dark:border-white shadow-[2px_2px_0_#1A1A1A]'
                          : 'border-[#1A1A1A]/20 dark:border-[#F8F7F4]/20 opacity-60'
                      }`}
                    >
                      {mins} Minutes
                    </button>
                  ))}
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-end gap-2.5 pt-3">
                <button
                  type="button"
                  onClick={() => setModalOpen(false)}
                  className="px-4 py-2 text-xs font-mono-display uppercase rounded-full border border-current opacity-60 hover:opacity-100 transition-colors cursor-pointer"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 text-xs font-mono-display uppercase rounded-full bg-[#4F46E5] hover:bg-[#4338CA] text-white shadow-[3px_3px_0_#1A1A1A] dark:shadow-[3px_3px_0_#6366F1] border-[1.5px] border-[#1A1A1A] dark:border-white/20 active:scale-95 transition-all flex items-center gap-1.5 cursor-pointer"
                >
                  <Check className="w-4 h-4" />
                  <span>{editingAlarmId ? 'Update Alarm' : 'Save Alarm'}</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {alarmToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-in fade-in duration-200">
          <div
            className={`w-full max-w-sm rounded-3xl p-6 shadow-2xl border-[1.5px] text-center ${
              isDark
                ? 'bg-[#18181B] border-[#F8F7F4]/40 text-[#F8F7F4] shadow-[8px_8px_0_#6366F1]'
                : 'bg-white border-[#1A1A1A] text-[#1A1A1A] shadow-[8px_8px_0_#1A1A1A]'
            }`}
          >
            <div className="w-12 h-12 mx-auto rounded-full bg-rose-500/15 text-rose-500 flex items-center justify-center mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>

            <h3 className="font-serif-display text-xl font-bold mb-1">Delete Alarm?</h3>
            <p className="text-xs opacity-75 mb-4">
              Are you sure you want to delete{' '}
              <strong>"{alarmToDelete.label || 'Alarm'}"</strong> set for{' '}
              <strong>
                {formatAlarmTime(alarmToDelete.time, format).time}{' '}
                {formatAlarmTime(alarmToDelete.time, format).period}
              </strong>
              ?
            </p>

            <div className="flex gap-2.5">
              <button
                type="button"
                onClick={() => setAlarmToDelete(null)}
                className="flex-1 py-2 text-xs font-mono-display uppercase rounded-full border border-current opacity-60 hover:opacity-100 cursor-pointer"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => {
                  soundManager.playTap();
                  onDeleteAlarm(alarmToDelete.id);
                  setAlarmToDelete(null);
                }}
                className="flex-1 py-2 text-xs font-mono-display uppercase rounded-full bg-rose-600 hover:bg-rose-700 text-white shadow-[2px_2px_0_#1A1A1A] border-[1.5px] border-[#1A1A1A] active:scale-95 cursor-pointer"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Alarms List */}
      <div className="w-full space-y-4">
        {sortedAlarms.length === 0 ? (
          <div
            className={`w-full py-12 px-4 rounded-3xl border-[1.5px] flex flex-col items-center justify-center text-center ${
              isDark
                ? 'border-[#F8F7F4]/20 bg-[#18181B] text-[#F8F7F4]/60'
                : 'border-[#1A1A1A] bg-white text-[#1A1A1A]/60'
            }`}
          >
            <AlarmClock className="w-10 h-10 text-[#4F46E5] dark:text-[#818CF8] mb-3" />
            <h3 className="font-serif-display text-xl font-semibold text-[#1A1A1A] dark:text-[#F8F7F4] mb-1">
              No Alarms Configured
            </h3>
            <p className="text-xs max-w-xs mb-4">
              Set custom waking alarms with repeat schedules, custom labels, and snooze settings.
            </p>
            <button
              onClick={handleOpenAdd}
              className="px-4 py-2 rounded-full bg-[#4F46E5] text-white text-xs font-mono-display uppercase border-[1.5px] border-[#1A1A1A] shadow-[2px_2px_0_#1A1A1A] active:scale-95 transition-all inline-flex items-center gap-1.5 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Set First Alarm</span>
            </button>
          </div>
        ) : (
          sortedAlarms.map((alarm) => {
            const formatted = formatAlarmTime(alarm.time, format);
            const until = getTimeUntilAlarm(alarm, currentTick);
            const nextDate = getNextTriggerDate(alarm, currentTick);

            let nextDisplay = '';
            if (alarm.enabled && nextDate) {
              const isToday =
                nextDate.toDateString() === currentTick.toDateString();
              const tomorrow = new Date(currentTick);
              tomorrow.setDate(tomorrow.getDate() + 1);
              const isTomorrow =
                nextDate.toDateString() === tomorrow.toDateString();

              if (isToday) nextDisplay = `Today, ${until?.text}`;
              else if (isTomorrow) nextDisplay = `Tomorrow, ${until?.text}`;
              else
                nextDisplay = `${DAY_LABELS[nextDate.getDay()]}, ${
                  until?.text
                }`;
            }

            return (
              <div
                key={alarm.id}
                className={`w-full p-4 sm:p-5 rounded-2xl border-[1.5px] transition-all duration-200 flex items-center justify-between group ${
                  alarm.enabled
                    ? isDark
                      ? 'bg-[#18181B] border-[#F8F7F4]/30 shadow-[4px_4px_0_#6366F1] text-[#F8F7F4]'
                      : 'bg-white border-[#1A1A1A] shadow-[4px_4px_0_#1A1A1A] text-[#1A1A1A]'
                    : isDark
                    ? 'bg-[#18181B]/40 border-[#F8F7F4]/10 opacity-50'
                    : 'bg-white/50 border-[#1A1A1A]/30 opacity-50'
                }`}
              >
                {/* Alarm Time & Label */}
                <div
                  onClick={() => handleOpenEdit(alarm)}
                  className="flex flex-col cursor-pointer flex-1 mr-3 group"
                  title="Click to edit alarm"
                >
                  <div className="flex items-baseline gap-2">
                    <span className="text-2xl sm:text-3xl font-bold font-mono-display tracking-tight group-hover:text-[#4F46E5] dark:group-hover:text-[#818CF8] transition-colors">
                      {formatted.time}
                    </span>
                    {formatted.period && (
                      <span className="text-xs sm:text-sm font-bold font-mono-display text-[#4F46E5] dark:text-[#818CF8]">
                        {formatted.period}
                      </span>
                    )}
                  </div>

                  <div className="flex flex-wrap items-center gap-2 mt-1">
                    <span className="font-serif-display text-base font-semibold">
                      {alarm.label || 'Alarm'}
                    </span>
                    <span className="opacity-40">•</span>
                    <span className="label-mono">
                      {formatScheduleBadge(alarm.repeatDays)}
                    </span>
                    {alarm.snoozeDuration && (
                      <span className="label-mono border border-current px-1.5 py-0.2 rounded">
                        {alarm.snoozeDuration}m snooze
                      </span>
                    )}
                  </div>

                  {alarm.enabled && nextDisplay && (
                    <div className="text-xs font-mono-display text-[#4F46E5] dark:text-[#818CF8] font-bold mt-1">
                      Rings {nextDisplay}
                    </div>
                  )}
                </div>

                {/* Right controls: Edit, Toggle & Delete */}
                <div className="flex items-center gap-2 sm:gap-3">
                  <button
                    onClick={() => handleOpenEdit(alarm)}
                    title="Edit alarm"
                    className="p-2 rounded-full border border-transparent hover:border-current transition-colors cursor-pointer opacity-70 hover:opacity-100"
                  >
                    <Edit3 className="w-4 h-4" />
                  </button>

                  {/* Switch Toggle */}
                  <button
                    id={`toggle-alarm-${alarm.id}`}
                    onClick={() => {
                      soundManager.playTap();
                      onToggleAlarm(alarm.id);
                    }}
                    role="switch"
                    aria-checked={alarm.enabled}
                    title={alarm.enabled ? 'Disable alarm' : 'Enable alarm'}
                    className={`w-12 h-7 flex items-center rounded-full p-1 border-[1.5px] border-[#1A1A1A] dark:border-white/30 transition-all duration-300 cursor-pointer ${
                      alarm.enabled
                        ? 'bg-[#4F46E5]'
                        : isDark
                        ? 'bg-transparent'
                        : 'bg-black/10'
                    }`}
                  >
                    <div
                      className={`bg-white w-4 h-4 rounded-full border border-black/20 shadow-sm transform transition-transform duration-300 ${
                        alarm.enabled ? 'translate-x-5' : 'translate-x-0'
                      }`}
                    />
                  </button>

                  <button
                    id={`delete-alarm-${alarm.id}`}
                    onClick={() => {
                      soundManager.playTap();
                      setAlarmToDelete(alarm);
                    }}
                    title="Delete alarm"
                    className="p-2 rounded-full border border-transparent hover:border-rose-500/50 hover:bg-rose-500/10 text-slate-400 hover:text-rose-500 transition-colors cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
