import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, RotateCcw, Plus } from 'lucide-react';
import { ThemeMode } from '../types';
import { soundManager } from '../utils/audioAlert';

interface TimerTabProps {
  theme: ThemeMode;
  onTimerFinished: () => void;
  onRunningChange?: (isRunning: boolean) => void;
}

const PRESETS = [
  { label: '1 min', seconds: 60 },
  { label: '3 min', seconds: 180 },
  { label: '5 min', seconds: 300 },
  { label: '10 min', seconds: 600 },
  { label: '15 min', seconds: 900 },
  { label: '25m Focus', seconds: 1500 },
  { label: '30 min', seconds: 1800 },
  { label: '1 hr', seconds: 3600 },
];

export const TimerTab: React.FC<TimerTabProps> = ({
  theme,
  onTimerFinished,
  onRunningChange,
}) => {
  const isDark = theme === 'dark';

  const [setHours, setSetHours] = useState(0);
  const [setMinutes, setSetMinutes] = useState(5);
  const [setSeconds, setSetSeconds] = useState(0);

  const [totalSeconds, setTotalSeconds] = useState(300);
  const [remainingSeconds, setRemainingSeconds] = useState(300);
  const [isRunning, setIsRunning] = useState(false);
  const [, setIsFinished] = useState(false);

  const timerRef = useRef<any>(null);
  const targetEndTimeRef = useRef<number>(0);

  useEffect(() => {
    onRunningChange?.(isRunning);
  }, [isRunning, onRunningChange]);

  useEffect(() => {
    if (isRunning) {
      targetEndTimeRef.current = Date.now() + remainingSeconds * 1000;

      timerRef.current = setInterval(() => {
        const remaining = Math.max(
          0,
          Math.ceil((targetEndTimeRef.current - Date.now()) / 1000)
        );

        setRemainingSeconds(remaining);

        if (remaining <= 0) {
          clearInterval(timerRef.current);
          timerRef.current = null;
          setIsRunning(false);
          setIsFinished(true);
          onTimerFinished();
        }
      }, 250);
    } else {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [isRunning, onTimerFinished]);

  const handleStart = () => {
    soundManager.playTap();
    if (remainingSeconds <= 0) {
      const calculated = setHours * 3600 + setMinutes * 60 + setSeconds;
      if (calculated === 0) return;
      setTotalSeconds(calculated);
      setRemainingSeconds(calculated);
    }
    setIsFinished(false);
    setIsRunning(true);
  };

  const handlePause = () => {
    soundManager.playTap();
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    setIsRunning(false);
  };

  const handleReset = () => {
    soundManager.playTap();
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    setIsRunning(false);
    setIsFinished(false);
    const calculated = setHours * 3600 + setMinutes * 60 + setSeconds;
    setRemainingSeconds(calculated || 300);
    setTotalSeconds(calculated || 300);
  };

  const handleAddMinute = () => {
    soundManager.playTap();
    setRemainingSeconds((prev) => {
      const next = prev + 60;
      if (isRunning) {
        targetEndTimeRef.current += 60000;
      }
      return next;
    });
    setTotalSeconds((prev) => prev + 60);
  };

  const handleApplyPreset = (sec: number) => {
    soundManager.playTap();
    if (timerRef.current) {
      clearInterval(timerRef.current);
      timerRef.current = null;
    }
    setIsRunning(false);
    setIsFinished(false);
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    setSetHours(h);
    setSetMinutes(m);
    setSetSeconds(s);
    setTotalSeconds(sec);
    setRemainingSeconds(sec);
  };

  const formatRemaining = (totalSec: number) => {
    const h = Math.floor(totalSec / 3600);
    const m = Math.floor((totalSec % 3600) / 60);
    const s = totalSec % 60;

    return {
      hours: h > 0 ? String(h).padStart(2, '0') : null,
      minutes: String(m).padStart(2, '0'),
      seconds: String(s).padStart(2, '0'),
    };
  };

  const timeFormatted = formatRemaining(remainingSeconds);
  const progressRatio = totalSeconds > 0 ? remainingSeconds / totalSeconds : 1;

  return (
    <div id="timer-tab-container" className="w-full max-w-xl mx-auto flex flex-col items-center py-4">
      {/* Main Timer Display Card */}
      <div
        id="timer-card"
        className={`relative w-full rounded-3xl p-6 sm:p-10 flex flex-col items-center justify-center border-[1.5px] transition-all duration-300 ${
          isDark
            ? 'bg-[#18181B] border-[#F8F7F4]/30 shadow-[6px_6px_0_#6366F1] text-[#F8F7F4]'
            : 'bg-white border-[#1A1A1A] shadow-[6px_6px_0_#1A1A1A] text-[#1A1A1A]'
        }`}
      >
        <span className="label-mono text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60 mb-2">
          Countdown Engine
        </span>

        {/* Circle Countdown Display */}
        <div className="relative w-60 h-60 sm:w-72 sm:h-72 flex items-center justify-center my-3">
          <svg className="w-full h-full -rotate-90" viewBox="0 0 100 100">
            <circle
              cx="50"
              cy="50"
              r="44"
              className={isDark ? 'stroke-white/10' : 'stroke-black/10'}
              strokeWidth="2.5"
              fill="none"
            />
            <circle
              cx="50"
              cy="50"
              r="44"
              className="stroke-[#4F46E5] dark:stroke-[#818CF8] transition-all duration-1000 ease-linear"
              strokeWidth="3.5"
              strokeDasharray="276.46"
              strokeDashoffset={276.46 * (1 - progressRatio)}
              strokeLinecap="round"
              fill="none"
            />
          </svg>

          {/* Time digits in center */}
          <div className="absolute inset-0 flex flex-col items-center justify-center select-none font-mono-display">
            <div className="flex items-baseline">
              {timeFormatted.hours && (
                <>
                  <span className="text-3xl sm:text-4xl font-bold">
                    {timeFormatted.hours}
                  </span>
                  <span className="text-xl sm:text-2xl font-light text-[#4F46E5] dark:text-[#818CF8] mx-0.5">
                    :
                  </span>
                </>
              )}
              <span className="text-4xl sm:text-5xl font-bold tracking-tight">
                {timeFormatted.minutes}
              </span>
              <span className="text-2xl sm:text-3xl font-light text-[#4F46E5] dark:text-[#818CF8] mx-0.5">
                :
              </span>
              <span className="text-4xl sm:text-5xl font-bold tracking-tight">
                {timeFormatted.seconds}
              </span>
            </div>

            <span className="label-mono text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60 mt-3">
              {Math.round(progressRatio * 100)}% remaining
            </span>
          </div>
        </div>

        {/* Action Controls */}
        <div className="w-full flex items-center justify-center gap-4 mt-6">
          {/* Reset button */}
          <button
            id="timer-reset-button"
            onClick={handleReset}
            disabled={remainingSeconds === totalSeconds && !isRunning}
            className={`w-16 h-16 sm:w-18 sm:h-18 rounded-2xl flex flex-col items-center justify-center gap-1 text-xs font-mono-display uppercase tracking-wider border-[1.5px] transition-all active:scale-95 cursor-pointer disabled:opacity-30 disabled:cursor-not-allowed ${
              isDark
                ? 'bg-[#121214] border-[#F8F7F4]/30 text-[#F8F7F4] hover:bg-[#F8F7F4]/10'
                : 'bg-[#F8F7F4] border-[#1A1A1A] text-[#1A1A1A] hover:bg-[#1A1A1A]/5'
            }`}
          >
            <RotateCcw className="w-5 h-5 opacity-70" />
            <span>Reset</span>
          </button>

          {/* Start / Pause button */}
          <button
            id="timer-start-pause-button"
            onClick={isRunning ? handlePause : handleStart}
            className={`w-20 h-20 sm:w-24 sm:h-24 rounded-2xl flex flex-col items-center justify-center gap-1 text-xs font-mono-display uppercase tracking-wider border-[1.5px] shadow-[4px_4px_0_#1A1A1A] dark:shadow-[4px_4px_0_#6366F1] active:scale-95 transition-all cursor-pointer ${
              isRunning
                ? 'bg-amber-500 hover:bg-amber-600 text-white border-[#1A1A1A] dark:border-white/20'
                : 'bg-[#4F46E5] hover:bg-[#4338CA] text-white border-[#1A1A1A] dark:border-white/20'
            }`}
          >
            {isRunning ? (
              <>
                <Pause className="w-7 h-7 fill-current" />
                <span>Pause</span>
              </>
            ) : (
              <>
                <Play className="w-7 h-7 ml-1 fill-current" />
                <span>
                  {remainingSeconds < totalSeconds && remainingSeconds > 0
                    ? 'Resume'
                    : 'Start'}
                </span>
              </>
            )}
          </button>

          {/* +1 Min Button */}
          <button
            id="timer-add-minute-button"
            onClick={handleAddMinute}
            className={`w-16 h-16 sm:w-18 sm:h-18 rounded-2xl flex flex-col items-center justify-center gap-1 text-xs font-mono-display uppercase tracking-wider border-[1.5px] transition-all active:scale-95 cursor-pointer ${
              isDark
                ? 'bg-[#121214] border-[#F8F7F4]/30 text-[#818CF8] hover:bg-[#F8F7F4]/10'
                : 'bg-[#F8F7F4] border-[#1A1A1A] text-[#4F46E5] hover:bg-[#1A1A1A]/5'
            }`}
          >
            <Plus className="w-5 h-5" />
            <span>+1m</span>
          </button>
        </div>
      </div>

      {/* Timer Duration Picker */}
      {!isRunning && (
        <div
          className={`w-full mt-6 rounded-2xl p-5 border-[1.5px] transition-all ${
            isDark
              ? 'bg-[#18181B] border-[#F8F7F4]/30 text-[#F8F7F4]'
              : 'bg-white border-[#1A1A1A] text-[#1A1A1A]'
          }`}
        >
          <div className="flex items-center justify-between mb-3">
            <span className="label-mono text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60">
              Custom Duration
            </span>
            <span className="font-mono-display text-xs text-[#4F46E5] dark:text-[#818CF8] font-bold">
              {setHours > 0 ? `${setHours}h ` : ''}{setMinutes}m {setSeconds > 0 ? `${setSeconds}s` : ''}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-3 text-center">
            {/* Hours */}
            <div className="flex flex-col items-center p-3 rounded-xl border-[1.5px] border-[#1A1A1A]/20 dark:border-[#F8F7F4]/20">
              <label className="label-mono text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60 mb-1">Hours</label>
              <select
                value={setHours}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setSetHours(val);
                  const total = val * 3600 + setMinutes * 60 + setSeconds;
                  setTotalSeconds(total || 60);
                  setRemainingSeconds(total || 60);
                }}
                className="w-full text-center text-xl font-bold font-mono-display p-1 rounded-lg bg-transparent focus:outline-none cursor-pointer"
              >
                {Array.from({ length: 24 }, (_, i) => i).map((h) => (
                  <option key={h} value={h} className="dark:bg-[#18181B]">
                    {String(h).padStart(2, '0')}
                  </option>
                ))}
              </select>
            </div>

            {/* Minutes */}
            <div className="flex flex-col items-center p-3 rounded-xl border-[1.5px] border-[#1A1A1A]/20 dark:border-[#F8F7F4]/20">
              <label className="label-mono text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60 mb-1">Minutes</label>
              <select
                value={setMinutes}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setSetMinutes(val);
                  const total = setHours * 3600 + val * 60 + setSeconds;
                  setTotalSeconds(total || 60);
                  setRemainingSeconds(total || 60);
                }}
                className="w-full text-center text-xl font-bold font-mono-display p-1 rounded-lg bg-transparent focus:outline-none cursor-pointer"
              >
                {Array.from({ length: 60 }, (_, i) => i).map((m) => (
                  <option key={m} value={m} className="dark:bg-[#18181B]">
                    {String(m).padStart(2, '0')}
                  </option>
                ))}
              </select>
            </div>

            {/* Seconds */}
            <div className="flex flex-col items-center p-3 rounded-xl border-[1.5px] border-[#1A1A1A]/20 dark:border-[#F8F7F4]/20">
              <label className="label-mono text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60 mb-1">Seconds</label>
              <select
                value={setSeconds}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setSetSeconds(val);
                  const total = setHours * 3600 + setMinutes * 60 + val;
                  setTotalSeconds(total || 1);
                  setRemainingSeconds(total || 1);
                }}
                className="w-full text-center text-xl font-bold font-mono-display p-1 rounded-lg bg-transparent focus:outline-none cursor-pointer"
              >
                {Array.from({ length: 60 }, (_, i) => i).map((s) => (
                  <option key={s} value={s} className="dark:bg-[#18181B]">
                    {String(s).padStart(2, '0')}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>
      )}

      {/* Quick Presets */}
      <div
        className={`w-full mt-4 rounded-2xl p-5 border-[1.5px] transition-all ${
          isDark
            ? 'bg-[#18181B] border-[#F8F7F4]/30 text-[#F8F7F4]'
            : 'bg-white border-[#1A1A1A] text-[#1A1A1A]'
        }`}
      >
        <span className="label-mono block text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60 mb-3">
          Quick Presets
        </span>

        <div className="grid grid-cols-4 gap-2">
          {PRESETS.map((p) => (
            <button
              key={p.label}
              onClick={() => handleApplyPreset(p.seconds)}
              className={`py-2 px-1 rounded-xl text-xs font-mono-display font-semibold transition-all active:scale-95 border-[1.5px] cursor-pointer ${
                totalSeconds === p.seconds
                  ? 'bg-[#4F46E5] text-white border-[#1A1A1A] dark:border-white shadow-[2px_2px_0_#1A1A1A]'
                  : isDark
                  ? 'bg-[#121214] hover:bg-[#F8F7F4]/10 text-[#F8F7F4] border-[#F8F7F4]/20'
                  : 'bg-[#F8F7F4] hover:bg-[#1A1A1A]/5 text-[#1A1A1A] border-[#1A1A1A]/20'
              }`}
            >
              {p.label}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
};
