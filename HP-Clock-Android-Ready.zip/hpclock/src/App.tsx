import React, { useState, useEffect, useRef } from 'react';
import {
  Maximize2,
  Minimize2,
  Sun,
  Moon,
} from 'lucide-react';
import { ClockDisplay } from './components/ClockDisplay';
import { ClockControls } from './components/ClockControls';
import { AlarmTab } from './components/AlarmTab';
import { StopwatchTab } from './components/StopwatchTab';
import { TimerTab } from './components/TimerTab';
import { WorldClockTab } from './components/WorldClockTab';
import { BottomNav } from './components/BottomNav';
import { AlarmTriggerModal } from './components/AlarmTriggerModal';
import { TimerFinishedModal } from './components/TimerFinishedModal';
import {
  TimeFormat,
  ThemeMode,
  TimeData,
  ActiveTab,
  AlarmItem,
  WorldCity,
} from './types';
import { getTimeData } from './utils/timeUtils';
import { soundManager } from './utils/audioAlert';
import hpClockIcon from './assets/images/hp_clock_icon_1788071183554.jpg';

const INITIAL_ALARMS: AlarmItem[] = [
  {
    id: 'alarm-1',
    time: '07:00',
    label: 'Morning Wakeup',
    enabled: true,
    repeatDays: [1, 2, 3, 4, 5],
    createdAt: Date.now() - 10000,
  },
  {
    id: 'alarm-2',
    time: '08:30',
    label: 'Team Standup',
    enabled: false,
    repeatDays: [1, 2, 3, 4, 5],
    createdAt: Date.now() - 5000,
  },
];

const INITIAL_CITIES: WorldCity[] = [
  { id: 'london', city: 'London', country: 'United Kingdom', timeZone: 'Europe/London' },
  { id: 'new_york', city: 'New York', country: 'United States', timeZone: 'America/New_York' },
  { id: 'tokyo', city: 'Tokyo', country: 'Japan', timeZone: 'Asia/Tokyo' },
  { id: 'paris', city: 'Paris', country: 'France', timeZone: 'Europe/Paris' },
];

export default function App() {
  // Navigation State
  const [activeTab, setActiveTab] = useState<ActiveTab>('clock');

  // Clock format & settings
  const [format, setFormat] = useState<TimeFormat>(() => {
    const saved = localStorage.getItem('clock_format');
    return saved === '24h' || saved === '12h' ? saved : '12h';
  });

  const [theme, setTheme] = useState<ThemeMode>(() => {
    const saved = localStorage.getItem('clock_theme');
    if (saved === 'dark' || saved === 'light') return saved;
    if (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches) {
      return 'dark';
    }
    return 'light'; // Default to refined warm light per design variation
  });

  const [showSeconds, setShowSeconds] = useState<boolean>(() => {
    const saved = localStorage.getItem('clock_show_seconds');
    return saved !== null ? saved === 'true' : true;
  });

  const [isFullscreen, setIsFullscreen] = useState(false);

  // Alarms state
  const [alarms, setAlarms] = useState<AlarmItem[]>(() => {
    const saved = localStorage.getItem('clock_alarms');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return INITIAL_ALARMS;
  });

  // World cities state
  const [selectedCities, setSelectedCities] = useState<WorldCity[]>(() => {
    const saved = localStorage.getItem('clock_world_cities');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {}
    }
    return INITIAL_CITIES;
  });

  // Active status indicators for tabs
  const [isTimerRunning, setIsTimerRunning] = useState(false);
  const [isStopwatchRunning, setIsStopwatchRunning] = useState(false);

  // Trigger Modals
  const [ringingAlarm, setRingingAlarm] = useState<AlarmItem | null>(null);
  const [isTimerAlertOpen, setIsTimerAlertOpen] = useState(false);

  // Track last triggered alarm minute to avoid duplicate triggers within the same minute
  const lastTriggeredMinuteRef = useRef<string>('');

  // Clock Time state
  const [timeData, setTimeData] = useState<TimeData>(() =>
    getTimeData(new Date(), format)
  );

  // Time updater & Alarm checker
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTimeData(getTimeData(now, format));

      // Alarm evaluation
      const currentH = String(now.getHours()).padStart(2, '0');
      const currentM = String(now.getMinutes()).padStart(2, '0');
      const currentTimeStr = `${currentH}:${currentM}`;
      const currentDay = now.getDay();
      const currentMinuteKey = `${currentTimeStr}-${now.getDate()}`;

      if (lastTriggeredMinuteRef.current !== currentMinuteKey) {
        // Find matching active alarm
        const match = alarms.find((al) => {
          if (!al.enabled) return false;
          if (al.time !== currentTimeStr) return false;
          if (al.repeatDays.length === 0) return true; // One time
          return al.repeatDays.includes(currentDay);
        });

        if (match) {
          lastTriggeredMinuteRef.current = currentMinuteKey;
          setRingingAlarm(match);
        }
      }
    };

    updateTime();
    const interval = setInterval(updateTime, 250);
    return () => clearInterval(interval);
  }, [format, alarms]);

  // Preferences persistence
  useEffect(() => {
    localStorage.setItem('clock_format', format);
  }, [format]);

  useEffect(() => {
    localStorage.setItem('clock_theme', theme);
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('clock_show_seconds', String(showSeconds));
  }, [showSeconds]);

  useEffect(() => {
    localStorage.setItem('clock_alarms', JSON.stringify(alarms));
  }, [alarms]);

  useEffect(() => {
    localStorage.setItem('clock_world_cities', JSON.stringify(selectedCities));
  }, [selectedCities]);

  // Alarm management
  const handleAddAlarm = (alarmData: Omit<AlarmItem, 'id' | 'createdAt'>) => {
    const newAlarm: AlarmItem = {
      ...alarmData,
      id: `alarm-${Date.now()}`,
      createdAt: Date.now(),
    };
    setAlarms((prev) => [newAlarm, ...prev]);
  };

  const handleEditAlarm = (id: string, alarmData: Omit<AlarmItem, 'id' | 'createdAt'>) => {
    setAlarms((prev) =>
      prev.map((al) => (al.id === id ? { ...al, ...alarmData } : al))
    );
  };

  const handleToggleAlarm = (id: string) => {
    setAlarms((prev) =>
      prev.map((al) => (al.id === id ? { ...al, enabled: !al.enabled } : al))
    );
  };

  const handleDeleteAlarm = (id: string) => {
    setAlarms((prev) => prev.filter((al) => al.id !== id));
  };

  const handleDismissAlarm = () => {
    setRingingAlarm(null);
  };

  const handleSnoozeAlarm = (minutes: number) => {
    setRingingAlarm(null);
    const now = new Date();
    now.setMinutes(now.getMinutes() + minutes);
    const h = String(now.getHours()).padStart(2, '0');
    const m = String(now.getMinutes()).padStart(2, '0');
    const snoozeTime = `${h}:${m}`;

    const snoozedAlarm: AlarmItem = {
      id: `snooze-${Date.now()}`,
      time: snoozeTime,
      label: `Snooze (${minutes}m)`,
      enabled: true,
      repeatDays: [],
      createdAt: Date.now(),
    };

    setAlarms((prev) => [snoozedAlarm, ...prev]);
  };

  // World Cities Management
  const handleAddCity = (city: WorldCity) => {
    if (!selectedCities.some((c) => c.id === city.id)) {
      setSelectedCities((prev) => [...prev, city]);
    }
  };

  const handleRemoveCity = (cityId: string) => {
    setSelectedCities((prev) => prev.filter((c) => c.id !== cityId));
  };

  // Toggles
  const handleToggleFullscreen = () => {
    soundManager.playTap();
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      if (document.exitFullscreen) {
        document.exitFullscreen().catch(() => {});
      }
      setIsFullscreen(false);
    }
  };

  const handleToggleTheme = () => {
    soundManager.playTap();
    setTheme((prev) => (prev === 'dark' ? 'light' : 'dark'));
  };

  const handleToggleFormat = () => {
    soundManager.playTap();
    setFormat((prev) => (prev === '12h' ? '24h' : '12h'));
  };

  const handleToggleSeconds = () => {
    soundManager.playTap();
    setShowSeconds((prev) => !prev);
  };

  const isDark = theme === 'dark';

  return (
    <div
      id="hp-clock-main"
      className={`min-h-screen w-full flex flex-col justify-between transition-colors duration-500 pb-20 select-none ${
        isDark
          ? 'bg-[#121214] text-[#F8F7F4] selection:bg-[#6366F1] selection:text-white'
          : 'bg-[#F8F7F4] text-[#1A1A1A] selection:bg-[#4F46E5] selection:text-white'
      }`}
    >
      {/* Top App Header with Editorial Border matching design */}
      <header className="w-full px-4 sm:px-8 py-4 sm:py-6 border-b border-[#1A1A1A] dark:border-[#F8F7F4]/20 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl overflow-hidden border border-[#1A1A1A] dark:border-[#F8F7F4]/40 flex items-center justify-center bg-slate-900 shrink-0">
            <img
              src={hpClockIcon}
              alt="HP Clock Logo"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div>
            <span className="label block text-[#1A1A1A]/60 dark:text-[#F8F7F4]/60">
              Timepiece 01
            </span>
            <h1 className="display-font text-2xl sm:text-4xl font-semibold tracking-tight leading-none text-[#1A1A1A] dark:text-[#F8F7F4]">
              HP Clock
            </h1>
          </div>
        </div>

        {/* Right Header: Current Date and Utility Toggles */}
        <div className="flex items-center gap-3 sm:gap-6">
          <div className="label hidden md:block text-[#1A1A1A]/70 dark:text-[#F8F7F4]/70">
            {timeData.dayName}, {timeData.monthName} {timeData.dayOfMonth}, {timeData.year}
          </div>

          <div className="flex items-center gap-2">
            {/* Light/Dark Toggle */}
            <button
              onClick={handleToggleTheme}
              title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
              className="w-9 h-9 sm:w-10 sm:h-10 rounded-full border border-[#1A1A1A] dark:border-[#F8F7F4]/40 flex items-center justify-center transition-all hover:bg-[#1A1A1A]/5 dark:hover:bg-white/5 active:scale-95 cursor-pointer text-[#1A1A1A] dark:text-[#F8F7F4]"
            >
              {isDark ? (
                <Sun className="w-4 h-4 text-[#D4AF37]" />
              ) : (
                <Moon className="w-4 h-4 text-[#B8860B]" />
              )}
            </button>

            {/* Fullscreen Button */}
            <button
              id="fullscreen-button"
              onClick={handleToggleFullscreen}
              title={isFullscreen ? 'Exit Fullscreen' : 'Enter Fullscreen'}
              className="w-9 h-9 sm:w-10 sm:h-10 rounded-full border border-[#1A1A1A] dark:border-[#F8F7F4]/40 flex items-center justify-center transition-all hover:bg-[#1A1A1A]/5 dark:hover:bg-white/5 active:scale-95 cursor-pointer text-[#1A1A1A] dark:text-[#F8F7F4]"
            >
              {isFullscreen ? (
                <Minimize2 className="w-4 h-4" />
              ) : (
                <Maximize2 className="w-4 h-4" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Main Tab Content View */}
      <main className="w-full flex-1 flex flex-col items-center justify-center py-6 px-4 sm:px-6">
        <div className={`w-full ${activeTab === 'clock' ? 'block' : 'hidden'}`}>
          <div className="w-full animate-in fade-in duration-200 flex flex-col items-center">
            <ClockDisplay
              timeData={timeData}
              format={format}
              theme={theme}
              showSeconds={showSeconds}
            />

            <ClockControls
              format={format}
              onToggleFormat={handleToggleFormat}
              theme={theme}
              onToggleTheme={handleToggleTheme}
              showSeconds={showSeconds}
              onToggleSeconds={handleToggleSeconds}
            />
          </div>
        </div>

        <div className={`w-full ${activeTab === 'alarm' ? 'block' : 'hidden'}`}>
          <div className="w-full animate-in fade-in duration-200">
            <AlarmTab
              alarms={alarms}
              onAddAlarm={handleAddAlarm}
              onEditAlarm={handleEditAlarm}
              onToggleAlarm={handleToggleAlarm}
              onDeleteAlarm={handleDeleteAlarm}
              theme={theme}
              format={format}
            />
          </div>
        </div>

        <div className={`w-full ${activeTab === 'stopwatch' ? 'block' : 'hidden'}`}>
          <div className="w-full animate-in fade-in duration-200">
            <StopwatchTab
              theme={theme}
              onRunningChange={setIsStopwatchRunning}
            />
          </div>
        </div>

        <div className={`w-full ${activeTab === 'timer' ? 'block' : 'hidden'}`}>
          <div className="w-full animate-in fade-in duration-200">
            <TimerTab
              theme={theme}
              onTimerFinished={() => setIsTimerAlertOpen(true)}
              onRunningChange={setIsTimerRunning}
            />
          </div>
        </div>

        <div className={`w-full ${activeTab === 'worldclock' ? 'block' : 'hidden'}`}>
          <div className="w-full animate-in fade-in duration-200">
            <WorldClockTab
              theme={theme}
              format={format}
              selectedCities={selectedCities}
              onAddCity={handleAddCity}
              onRemoveCity={handleRemoveCity}
            />
          </div>
        </div>
      </main>

      {/* Alarm Ringing Modal */}
      {ringingAlarm && (
        <AlarmTriggerModal
          alarm={ringingAlarm}
          theme={theme}
          format={format}
          onDismiss={handleDismissAlarm}
          onSnooze={handleSnoozeAlarm}
        />
      )}

      {/* Timer Finished Alert Modal */}
      {isTimerAlertOpen && (
        <TimerFinishedModal
          theme={theme}
          onDismiss={() => setIsTimerAlertOpen(false)}
          onRestart={() => {
            setIsTimerAlertOpen(false);
            setActiveTab('timer');
          }}
        />
      )}

      {/* Fixed Editorial Nav Footer */}
      <BottomNav
        activeTab={activeTab}
        onTabChange={setActiveTab}
        theme={theme}
        alarmCount={alarms.filter((a) => a.enabled).length}
        activeTimerRunning={isTimerRunning}
        stopwatchRunning={isStopwatchRunning}
      />
    </div>
  );
}
