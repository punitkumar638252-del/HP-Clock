// Web Audio API Sound Synthesizer for Alarm & Timer Alerts

class SoundManager {
  private ctx: AudioContext | null = null;
  private isAlarmPlaying: boolean = false;
  private alarmInterval: any = null;

  private getContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      this.ctx = new AudioCtx();
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  // Play a pleasant beep tone
  playBeep(frequency: number = 880, duration: number = 0.15, type: OscillatorType = 'sine') {
    try {
      const ctx = this.getContext();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = type;
      osc.frequency.setValueAtTime(frequency, ctx.currentTime);

      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start();
      osc.stop(ctx.currentTime + duration);
    } catch (e) {
      console.warn('Audio playback not permitted yet:', e);
    }
  }

  // Play button click / tap feedback
  playTap() {
    this.playBeep(1200, 0.05, 'triangle');
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate(15);
      } catch (e) {}
    }
  }

  // Play a gentle two-tone chime
  playChime() {
    try {
      const ctx = this.getContext();
      const notes = [523.25, 659.25, 783.99, 1046.5]; // C5, E5, G5, C6
      notes.forEach((freq, idx) => {
        setTimeout(() => {
          this.playBeep(freq, 0.3, 'sine');
        }, idx * 120);
      });
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        try {
          navigator.vibrate([40, 60, 40]);
        } catch (e) {}
      }
    } catch (e) {
      console.warn(e);
    }
  }

  // Start continuous repeating Alarm tone
  startAlarmTone() {
    if (this.isAlarmPlaying) return;
    this.isAlarmPlaying = true;

    const playSequence = () => {
      if (!this.isAlarmPlaying) return;
      try {
        const ctx = this.getContext();
        // Play dual high beeps
        this.playBeep(880, 0.12, 'square');
        setTimeout(() => {
          if (this.isAlarmPlaying) this.playBeep(880, 0.12, 'square');
        }, 150);
        setTimeout(() => {
          if (this.isAlarmPlaying) this.playBeep(1046.5, 0.25, 'triangle');
        }, 320);

        if (typeof navigator !== 'undefined' && navigator.vibrate) {
          try {
            navigator.vibrate([300, 150, 300, 150, 400]);
          } catch (e) {}
        }
      } catch (e) {
        console.warn(e);
      }
    };

    playSequence();
    this.alarmInterval = setInterval(playSequence, 1200);
  }

  // Stop Alarm tone
  stopAlarmTone() {
    this.isAlarmPlaying = false;
    if (this.alarmInterval) {
      clearInterval(this.alarmInterval);
      this.alarmInterval = null;
    }
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      try {
        navigator.vibrate(0);
      } catch (e) {}
    }
  }

  // Play timer finished celebratory chime
  playTimerFinished() {
    try {
      this.startAlarmTone();
      // Auto stop after 15s if not dismissed
      setTimeout(() => {
        this.stopAlarmTone();
      }, 15000);
    } catch (e) {
      console.warn(e);
    }
  }
}

export const soundManager = new SoundManager();

