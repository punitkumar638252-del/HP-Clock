import { TimeData, TimeFormat } from '../types';

export function getTimeData(date: Date, format: TimeFormat): TimeData {
  const hours24 = date.getHours();
  const minutes = date.getMinutes();
  const seconds = date.getSeconds();
  const milliseconds = date.getMilliseconds();

  let displayHours = hours24;
  let period: 'AM' | 'PM' | '' = '';

  if (format === '12h') {
    period = hours24 >= 12 ? 'PM' : 'AM';
    displayHours = hours24 % 12;
    if (displayHours === 0) displayHours = 12;
  }

  const hoursStr = String(displayHours).padStart(2, '0');
  const minutesStr = String(minutes).padStart(2, '0');
  const secondsStr = String(seconds).padStart(2, '0');

  // Days & Months in English
  const dayNames = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  const dayName = dayNames[date.getDay()];
  const monthName = monthNames[date.getMonth()];
  const dayOfMonth = date.getDate();
  const year = date.getFullYear();

  // Timezone and UTC offset
  const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone || 'Local Time';
  
  const offsetMinutes = -date.getTimezoneOffset();
  const offsetHours = Math.floor(Math.abs(offsetMinutes) / 60);
  const offsetMins = Math.abs(offsetMinutes) % 60;
  const sign = offsetMinutes >= 0 ? '+' : '-';
  const utcOffset = `UTC${sign}${String(offsetHours).padStart(2, '0')}:${String(offsetMins).padStart(2, '0')}`;

  const fullFormattedTime = `${hoursStr}:${minutesStr}:${secondsStr}${period ? ' ' + period : ''}`;
  const secondsRatio = (seconds * 1000 + milliseconds) / 60000;

  return {
    hoursStr,
    minutesStr,
    secondsStr,
    period,
    fullFormattedTime,
    dayName,
    monthName,
    dayOfMonth,
    year,
    timeZone,
    utcOffset,
    secondsRatio,
  };
}
