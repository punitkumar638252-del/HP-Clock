import { AlarmItem, TimeFormat } from '../types';

/**
 * Calculates the exact upcoming Date when an alarm will trigger next.
 */
export function getNextTriggerDate(alarm: AlarmItem, fromDate = new Date()): Date | null {
  if (!alarm.enabled) return null;

  const [hStr, mStr] = alarm.time.split(':');
  const targetHour = parseInt(hStr, 10);
  const targetMinute = parseInt(mStr, 10);

  if (isNaN(targetHour) || isNaN(targetMinute)) return null;

  const currentYear = fromDate.getFullYear();
  const currentMonth = fromDate.getMonth();
  const currentDate = fromDate.getDate();
  const currentDayOfWeek = fromDate.getDay(); // 0 = Sun, 1 = Mon...
  const currentHour = fromDate.getHours();
  const currentMinute = fromDate.getMinutes();

  // If once / non-repeating (empty repeatDays)
  if (!alarm.repeatDays || alarm.repeatDays.length === 0) {
    const candidateToday = new Date(currentYear, currentMonth, currentDate, targetHour, targetMinute, 0, 0);
    if (candidateToday.getTime() > fromDate.getTime()) {
      return candidateToday;
    }
    // Else tomorrow
    const candidateTomorrow = new Date(currentYear, currentMonth, currentDate + 1, targetHour, targetMinute, 0, 0);
    return candidateTomorrow;
  }

  // Repeating alarm
  // Check next 7 days starting today (dayOffset = 0..7)
  for (let dayOffset = 0; dayOffset <= 7; dayOffset++) {
    const checkDayOfWeek = (currentDayOfWeek + dayOffset) % 7;
    if (alarm.repeatDays.includes(checkDayOfWeek)) {
      const candidate = new Date(
        currentYear,
        currentMonth,
        currentDate + dayOffset,
        targetHour,
        targetMinute,
        0,
        0
      );

      // If checking today, time must be in the future (or at least same minute if fromDate is before)
      if (dayOffset === 0) {
        if (targetHour > currentHour || (targetHour === currentHour && targetMinute > currentMinute)) {
          return candidate;
        }
      } else {
        return candidate;
      }
    }
  }

  // Fallback next week
  const firstDay = alarm.repeatDays[0];
  const daysUntil = (firstDay - currentDayOfWeek + 7) % 7 || 7;
  return new Date(currentYear, currentMonth, currentDate + daysUntil, targetHour, targetMinute, 0, 0);
}

/**
 * Returns formatted time difference till next alarm trigger
 */
export function getTimeUntilAlarm(
  alarm: AlarmItem,
  fromDate = new Date()
): { diffMs: number; hours: number; minutes: number; text: string; date: Date } | null {
  const triggerDate = getNextTriggerDate(alarm, fromDate);
  if (!triggerDate) return null;

  const diffMs = triggerDate.getTime() - fromDate.getTime();
  if (diffMs < 0) return null;

  const totalMinutes = Math.floor(diffMs / 60000);
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;

  let text = '';
  if (hours === 0 && minutes === 0) {
    text = 'in less than a minute';
  } else if (hours === 0) {
    text = `in ${minutes}m`;
  } else if (minutes === 0) {
    text = `in ${hours}h`;
  } else {
    text = `in ${hours}h ${minutes}m`;
  }

  return { diffMs, hours, minutes, text, date: triggerDate };
}

/**
 * Sorts alarms:
 * 1. Enabled alarms sorted by earliest next trigger date
 * 2. Disabled alarms sorted by their 24h time string
 */
export function sortAlarmsByNextTrigger(alarms: AlarmItem[], fromDate = new Date()): AlarmItem[] {
  return [...alarms].sort((a, b) => {
    // If one is enabled and the other is disabled, enabled comes first
    if (a.enabled && !b.enabled) return -1;
    if (!a.enabled && b.enabled) return 1;

    // Both enabled: sort by next trigger date
    if (a.enabled && b.enabled) {
      const nextA = getNextTriggerDate(a, fromDate)?.getTime() ?? Number.MAX_SAFE_INTEGER;
      const nextB = getNextTriggerDate(b, fromDate)?.getTime() ?? Number.MAX_SAFE_INTEGER;
      return nextA - nextB;
    }

    // Both disabled: sort by alarm time 'HH:MM'
    return a.time.localeCompare(b.time);
  });
}

/**
 * Format 24h time to 12h/24h display
 */
export function formatAlarmTime(time24: string, format: TimeFormat): { time: string; period: string } {
  const [hStr, mStr] = time24.split(':');
  const h = parseInt(hStr, 10);
  const m = parseInt(mStr, 10);

  if (isNaN(h) || isNaN(m)) return { time: time24, period: '' };

  if (format === '24h') {
    return {
      time: `${String(h).padStart(2, '0')}:${String(m).padStart(2, '0')}`,
      period: '',
    };
  }

  const period = h >= 12 ? 'PM' : 'AM';
  let h12 = h % 12;
  if (h12 === 0) h12 = 12;

  return {
    time: `${String(h12).padStart(2, '0')}:${String(m).padStart(2, '0')}`,
    period,
  };
}
