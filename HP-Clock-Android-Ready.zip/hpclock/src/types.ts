export type TimeFormat = '12h' | '24h';
export type ThemeMode = 'dark' | 'light';
export type ActiveTab = 'clock' | 'alarm' | 'stopwatch' | 'timer' | 'worldclock';

export interface ClockSettings {
  format: TimeFormat;
  theme: ThemeMode;
  showSeconds: boolean;
  showDate: boolean;
}

export interface TimeData {
  hoursStr: string;
  minutesStr: string;
  secondsStr: string;
  period: 'AM' | 'PM' | '';
  fullFormattedTime: string;
  dayName: string;
  monthName: string;
  dayOfMonth: number;
  year: number;
  timeZone: string;
  utcOffset: string;
  secondsRatio: number;
}

export interface AlarmItem {
  id: string;
  time: string; // 'HH:MM' 24h format
  label: string;
  enabled: boolean;
  repeatDays: number[]; // 0 for Sun, 1 for Mon, etc. Empty means one-time today/tomorrow
  snoozeCount?: number;
  snoozeDuration?: number; // in minutes (5, 10, or 15)
  createdAt: number;
}

export interface LapRecord {
  lapNumber: number;
  time: number; // overall time in ms
  lapDuration: number; // lap split in ms
}

export interface WorldCity {
  id: string;
  city: string;
  country: string;
  timeZone: string;
}
